#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
poster.py —— 海报页 / 海报图生成器（零第三方依赖）

由文章的前置信息（标题 / 副标题 / 金句 / 作者 / 章节）渲染一张定尺海报页。

画布比例
  3:4   1080×1440   默认，公众号次图、朋友圈
  4:5   1080×1350   小红书
  1:1   1080×1080   方图、头像墙
  9:16  1080×1920   竖屏、故事

版式
  cover  封面海报：栏目 + 大标题 + 副标题 + 金句 + 署名（默认）
  list   目录海报：标题 + 前 N 个章节
  quote  金句海报：整张只放金句

产物
  HTML  固定像素画布，浏览器打开即可看、可截图、可打印
  PNG   export_png() 调用本机已安装的 Chrome / Edge / Chromium 无头截图；
        没装浏览器时只出 HTML，并返回 None（不阻断交付）

用法（一般由 md2html.py --mode poster 调用，也可单独用）：
  python3 poster.py 文章.md                      # 出 3:4 封面海报 HTML
  python3 poster.py 文章.md --ratio 4:5 --png    # 同时截图为 PNG
  python3 poster.py 文章.md --layout quote
"""
import os
import re
import math
import html
import shutil
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from theme import THEMES, DEFAULT_THEME  # noqa: E402

RATIOS = {
    "3:4": (1080, 1440),
    "4:5": (1080, 1350),
    "1:1": (1080, 1080),
    "9:16": (1080, 1920),
}
LAYOUTS = ("cover", "list", "quote")

# 常见浏览器位置（macOS 安装路径 + PATH 里的命令名）
_BROWSERS = [
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
    "/Applications/Chromium.app/Contents/MacOS/Chromium",
    "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
    "google-chrome", "chromium", "chromium-browser", "microsoft-edge",
]


def _esc(s) -> str:
    return html.escape(str(s or ""), quote=False)


def _fit(text, box_w, box_h, size_max, size_min, line_height=1.18) -> int:
    """按可用宽高估算能放下的最大字号（中文按 1 字 ≈ 1 em 估算）。"""
    text = (text or "").strip() or " "
    size = size_min
    for size in range(size_max, size_min - 1, -2):
        cpl = max(4, int(box_w / size))
        lines = sum(max(1, math.ceil(len(p) / cpl)) for p in text.split("\n"))
        if lines * size * line_height <= box_h:
            return size
    return size


def _find_browser():
    for b in _BROWSERS:
        if os.path.isabs(b):
            if os.path.exists(b):
                return b
        else:
            p = shutil.which(b)
            if p:
                return p
    return None


def _css(W, H, v, dark=False) -> str:
    """海报样式：所有尺寸写死像素，保证截图与浏览器所见一致。"""
    pad = int(W * 0.089)
    txt = v["--text"]
    t2 = v["--text-2"]
    t3 = v["--text-3"]
    line = v["--line"]
    acc = v["--accent"]
    acc_rgb = v["--accent-rgb"]
    teal_rgb = v["--teal-rgb"]
    bg = v["--bg"]
    elev = v["--bg-elev"]
    radius = v["--radius-l"]
    return """
* { margin:0; padding:0; box-sizing:border-box; }
html, body { background:%(bg)s; }
body { -webkit-font-smoothing:antialiased; -moz-osx-font-smoothing:grayscale; }
.poster {
  position:relative; width:%(W)dpx; height:%(H)dpx; overflow:hidden;
  background:
    radial-gradient(circle at 86%% -6%%, rgba(%(acc_rgb)s,.20), transparent 52%%),
    radial-gradient(circle at 4%% 104%%, rgba(%(teal_rgb)s,.16), transparent 54%%),
    linear-gradient(165deg, %(elev)s 0%%, %(bg)s 62%%);
  font-family:-apple-system, BlinkMacSystemFont, "SF Pro Display", "PingFang SC",
              "Hiragino Sans GB", "Microsoft YaHei", sans-serif;
  color:%(txt)s;
}
.glow { position:absolute; border-radius:50%%; filter:blur(90px); opacity:.55; }
.glow.a { width:%(gl)dpx; height:%(gl)dpx; right:%(gn)dpx; top:%(gn)dpx;
          background:rgba(%(acc_rgb)s,.32); }
.glow.b { width:%(gl2)dpx; height:%(gl2)dpx; left:%(gn2)dpx; bottom:%(gn2)dpx;
          background:rgba(%(teal_rgb)s,.26); }
.inner {
  position:relative; z-index:2; height:100%%;
  padding:%(pad)dpx; display:flex; flex-direction:column; justify-content:space-between;
}
.top { display:flex; align-items:center; justify-content:space-between; }
.kicker {
  display:inline-flex; align-items:center; gap:%(gap)dpx;
  font-size:%(f_kick)dpx; font-weight:600; letter-spacing:.16em; text-transform:uppercase;
  color:%(t2)s; background:rgba(%(acc_rgb)s,.09);
  border:1px solid rgba(%(acc_rgb)s,.22); border-radius:999px;
  padding:%(kickpad)dpx %(kickpad2)dpx; max-width:%(kw)dpx;
}
.kicker::before {
  content:""; width:%(dot)dpx; height:%(dot)dpx; border-radius:50%%;
  background:%(acc)s; flex:0 0 auto;
}
.mark {
  font-family:ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size:%(f_mark)dpx; font-weight:700; letter-spacing:-.02em;
  color:%(t3)s;
}
.mid { display:flex; flex-direction:column; justify-content:center; }
h1.title {
  font-size:%(f_title)dpx; line-height:1.16; letter-spacing:-.022em;
  font-weight:700; color:%(txt)s; max-width:%(w)dpx;
}
.rule { width:%(rule)dpx; height:%(ruleh)dpx; border-radius:2px; margin:%(rulem)s;
        background:linear-gradient(90deg, %(acc)s, rgba(%(teal_rgb)s,1)); }
.subtitle {
  font-size:%(f_sub)dpx; line-height:1.62; color:%(t2)s;
  max-width:%(w)s; font-weight:400; margin-top:%(subm)dpx;
}
.quote {
  margin-top:%(qm)dpx; padding:%(qp)dpx %(qp2)dpx;
  border-left:%(qb)dpx solid %(acc)s;
  background:rgba(%(acc_rgb)s,.06);
  border-radius:0 %(radius)s %(radius)s 0;
  font-size:%(f_quote)dpx; line-height:1.66; color:%(txt)s;
  max-width:%(qw)dpx;
}
.bot { display:flex; flex-direction:column; gap:%(botg)dpx; }
.divider { height:1px; background:%(line)s; }
.meta {
  display:flex; flex-wrap:wrap; align-items:center; gap:%(metag)dpx;
  font-size:%(f_meta)dpx; color:%(t2)s;
  font-family:ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  letter-spacing:.02em;
}
.meta i { font-style:normal; color:%(t3)s; }
.tags { display:flex; flex-wrap:wrap; gap:%(taggap)dpx; }
.tags span {
  font-size:%(f_tag)dpx; color:%(t2)s; background:%(elev)s;
  border:1px solid %(line)s; border-radius:999px; padding:%(tagpad)dpx %(tagpad2)dpx;
}
.brand {
  display:flex; align-items:center; justify-content:space-between;
  font-size:%(f_brand)dpx; color:%(t3)s; letter-spacing:.04em;
}
.brand b { color:%(t2)s; font-weight:600; letter-spacing:.02em; }
/* 目录版式 */
.list { display:flex; flex-direction:column; gap:%(lg)dpx; margin-top:%(lm)dpx; }
.item { display:flex; align-items:baseline; gap:%(ig)dpx; padding-bottom:%(ip)dpx;
        border-bottom:1px solid %(line)s; }
.item:last-child { border-bottom:none; padding-bottom:0; }
.item .no {
  font-family:ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size:%(f_no)dpx; font-weight:600; color:%(acc)s; min-width:%(now)dpx;
}
.item .tx { font-size:%(f_it)dpx; line-height:1.4; color:%(txt)s; }
/* 金句版式 */
.quote-only { flex:1; display:flex; flex-direction:column; justify-content:center; }
.quote-only .qm {
  font-size:%(f_qm)dpx; line-height:.68; color:rgba(%(acc_rgb)s,.30);
  font-family:Georgia, "Times New Roman", serif; margin-bottom:%(qmm)dpx;
}
.quote-only .tx {
  font-size:%(f_qt)dpx; line-height:1.5; font-weight:700; letter-spacing:-.02em;
  color:%(txt)s; max-width:%(w)s;
}
@media print { @page { size:%(W)dpx %(H)dpx; margin:0; } html,body { width:%(W)dpx; } }
""" % dict(
        W=W, H=H, pad=pad, bg=bg, elev=elev, txt=txt, t2=t2, t3=t3, line=line, acc=acc,
        acc_rgb=acc_rgb, teal_rgb=teal_rgb, radius=radius, w=W - pad * 2,
        gl=int(W * .62), gl2=int(W * .5), gn=-int(W * .18), gn2=-int(W * .16),
        gap=int(W * .015), dot=int(W * .008), kw=int(W * .7),
        kickpad=int(W * .016), kickpad2=int(W * .028),
        f_kick=int(W * .0205), f_mark=int(W * .032),
        f_title=int(W * .075), rule=int(W * .11), ruleh=int(W * .0055),
        rulem="%dpx 0 %dpx" % (int(H * .028), int(H * .030)),
        f_sub=int(W * .0265), subm=int(H * .008),
        qm=int(H * .030), qp=int(W * .022), qp2=int(W * .028), qb=int(W * .0042),
        f_quote=int(W * .0255), qw=int(W * .82),
        botg=int(H * .026), metag=int(W * .022), f_meta=int(W * .0195),
        taggap=int(W * .011), f_tag=int(W * .0175), tagpad=int(W * .008), tagpad2=int(W * .019),
        f_brand=int(W * .0185),
        lg=int(H * .024), lm=int(H * .01), ig=int(W * .022), ip=int(H * .020),
        f_no=int(W * .023), now=int(W * .075), f_it=int(W * .0245),
        f_qm=int(W * .16), qmm=int(H * .03), f_qt=int(W * .052),
    )


def _chapter_items(chapters, limit=6):
    out = []
    for c in chapters[:limit]:
        num = _esc(c.get("num"))
        tx = str(c.get("title") or "").strip()
        # 标题自带编号（如 "01 为什么要规范化"）时去掉，避免与左侧编号重复
        if c.get("num") and tx.startswith(str(c.get("num"))):
            tx = re.sub(r"^%s[\s.、．:：)）-]*" % re.escape(str(c.get("num"))), "", tx)
        out.append('<div class="item"><span class="no">%s</span>'
                   '<span class="tx">%s</span></div>' % (num, _esc(tx)))
    return "".join(out)


def _meta_line(meta, st):
    bits = []
    author = meta.get("author")
    if isinstance(author, str) and author.strip():
        bits.append(_esc(author.strip()))
    date = meta.get("date")
    if isinstance(date, str) and date.strip():
        bits.append(_esc(date.strip()))
    src = meta.get("source")
    if isinstance(src, str) and src.strip():
        bits.append(_esc(src.strip()))
    if not bits:
        bits.append("%d 个章节" % len(st.get("chapters") or []))
    return '<i>·</i>'.join(bits)


def build_poster(st, meta, theme=DEFAULT_THEME, ratio="3:4", layout="cover") -> str:
    """由 doc.structure() 的结果渲染海报 HTML。

    st      md2html.Doc.structure() 的返回值
    meta    frontmatter 字典（支持 poster_* 覆盖字段）
    ratio   RATIOS 的键
    layout  LAYOUTS 之一
    """
    if ratio not in RATIOS:
        ratio = "3:4"
    if layout not in LAYOUTS:
        layout = "cover"
    W, H = RATIOS[ratio]

    theme_key = theme if theme in THEMES else DEFAULT_THEME
    t = THEMES[theme_key]
    v = t["vars"]
    is_dark = t.get("dark_vars") is None

    title = str(meta.get("poster_title") or st.get("title") or "未命名文档").strip()
    subtitle = str(meta.get("poster_subtitle") or st.get("subtitle") or "").strip()
    kicker = str(meta.get("poster_kicker") or meta.get("kicker")
                 or meta.get("column") or "").strip()
    quote = str(meta.get("poster_quote") or meta.get("quote")
                or st.get("hero_quote") or "").strip()
    brand = str(meta.get("poster_brand") or "MD工具助手").strip()
    footer = str(meta.get("poster_footer") or "排版生成").strip()
    mark = str(meta.get("poster_mark") or "MD").strip().upper()[:3]

    tags = meta.get("tags") or []
    if isinstance(tags, str):
        tags = [x.strip() for x in tags.replace("，", ",").split(",") if x.strip()]
    tags = [str(x) for x in tags][:4]

    pad = int(W * 0.089)
    box_w = W - pad * 2
    # 可用垂直空间：扣掉上下内边距、栏目行与底部信息块
    avail_h = H - pad * 2 - int(H * 0.20)

    title_size = _fit(title, box_w, int(avail_h * 0.52), int(W * 0.088), int(W * 0.036))
    css = _css(W, H, v, is_dark)

    kicker_html = ('<span class="kicker">%s</span>' % _esc(kicker)) if kicker else "<span></span>"
    top = '<div class="top">%s<span class="mark">%s</span></div>' % (kicker_html, _esc(mark))

    bot_bits = ['<div class="divider"></div>',
                '<div class="meta">%s</div>' % _meta_line(meta, st)]
    if tags:
        bot_bits.append('<div class="tags">%s</div>' % "".join(
            "<span>%s</span>" % _esc(x) for x in tags))
    bot_bits.append('<div class="brand"><b>%s</b><span>%s</span></div>' % (_esc(brand), _esc(footer)))
    bot = '<div class="bot">%s</div>' % "".join(bot_bits)

    if layout == "quote":
        text = quote or title
        q_size = _fit(text, box_w, int(H * 0.46), int(W * 0.062), int(W * 0.030), 1.5)
        mid = ('<div class="quote-only"><div class="qm">“</div>'
               '<div class="tx" style="font-size:%dpx">%s</div></div>'
               % (q_size, _esc(text)))
        body = top + mid + bot
    elif layout == "list":
        items = _chapter_items(st.get("chapters") or [], 6)
        mid = ['<div class="mid">',
               '<h1 class="title" style="font-size:%dpx">%s</h1>' % (title_size, _esc(title)),
               '<div class="rule"></div>']
        if subtitle:
            mid.append('<p class="subtitle">%s</p>' % _esc(subtitle))
        mid.append("</div>")
        mid.append('<div class="list">%s</div>' % items if items else "")
        body = top + "".join(mid) + bot
    else:  # cover
        size = title_size if title_size >= int(W * 0.052) else max(title_size, int(W * 0.052))
        mid = ['<div class="mid">',
               '<h1 class="title" style="font-size:%dpx">%s</h1>' % (size, _esc(title)),
               '<div class="rule"></div>']
        if subtitle:
            mid.append('<p class="subtitle">%s</p>' % _esc(subtitle))
        if quote:
            qs = _fit(quote, int(box_w * 0.82), int(H * 0.20), int(W * 0.028), int(W * 0.019), 1.66)
            mid.append('<div class="quote" style="font-size:%dpx">“%s”</div>' % (qs, _esc(quote)))
        mid.append("</div>")
        body = top + "".join(mid) + bot

    return (
        "<!DOCTYPE html>\n<html lang=\"zh-CN\">\n<head>\n<meta charset=\"UTF-8\">\n"
        "<title>%s · 海报 %s</title>\n<style>%s</style>\n</head>\n<body>\n"
        "<div class=\"poster\" id=\"poster\" data-ratio=\"%s\" data-layout=\"%s\">"
        "<div class=\"glow a\"></div><div class=\"glow b\"></div>"
        "<div class=\"inner\">%s</div></div>\n</body>\n</html>\n"
        % (_esc(title), ratio, css, ratio, layout, body)
    )


def export_png(html_path, png_path, ratio="3:4", scale=2):
    """用本机浏览器的无头模式把海报 HTML 截成 PNG。成功返回路径，失败返回 None。"""
    browser = _find_browser()
    if not browser:
        return None
    W, H = RATIOS.get(ratio, RATIOS["3:4"])
    url = "file://" + os.path.abspath(html_path)
    cmd = [
        browser, "--headless=new", "--disable-gpu", "--hide-scrollbars",
        "--force-device-scale-factor=%d" % scale,
        "--window-size=%d,%d" % (W, H),
        "--virtual-time-budget=1500",
        "--screenshot=" + os.path.abspath(png_path),
        url,
    ]
    try:
        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                       timeout=60, check=False)
    except Exception:
        return None
    return os.path.abspath(png_path) if os.path.exists(png_path) else None


def main():
    import argparse
    ap = argparse.ArgumentParser(description="Markdown → 海报页 / 海报图")
    ap.add_argument("input", help="Markdown 文件路径")
    ap.add_argument("-o", "--output", help="输出 HTML 路径（默认同名 .poster.html）")
    ap.add_argument("--ratio", default="3:4", help=" | ".join(RATIOS.keys()))
    ap.add_argument("--layout", default="cover", help=" | ".join(LAYOUTS))
    ap.add_argument("--theme", default=DEFAULT_THEME, help="azure | ink | warm")
    ap.add_argument("--scale", type=int, default=2, help="PNG 放大倍数（默认 2）")
    ap.add_argument("--png", action="store_true", help="同时截图为 PNG（需本机浏览器）")
    args = ap.parse_args()

    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from md2html import Doc, parse_frontmatter  # 延迟导入，避免循环依赖

    path = os.path.abspath(args.input)
    if not os.path.exists(path):
        print("找不到文件：%s" % path)
        sys.exit(1)

    md_text = open(path, encoding="utf-8").read()
    meta, body = parse_frontmatter(md_text)
    theme = meta.get("theme") if isinstance(meta.get("theme"), str) else ""
    theme = theme or args.theme
    doc = Doc(body, meta, theme, "poster", {"fallback_title": os.path.basename(path)})
    st = doc.structure()

    out = args.output or (os.path.splitext(path)[0] + ".poster.html")
    with open(out, "w", encoding="utf-8", newline="\n") as f:
        f.write(build_poster(st, meta, theme, args.ratio, args.layout))
    print("[poster] %s  (%d×%d)" % (out, *RATIOS.get(args.ratio, RATIOS["3:4"])))

    if args.png:
        png = os.path.splitext(out)[0] + ".png"
        got = export_png(out, png, args.ratio, args.scale)
        if got:
            print("[png] %s" % got)
        else:
            print("[png] 未找到本机浏览器（Chrome / Edge / Chromium），已跳过截图；"
                  "可用浏览器打开 HTML 后手动截图。")


if __name__ == "__main__":
    main()
