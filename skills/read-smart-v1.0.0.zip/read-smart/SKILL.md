---
name: read-smart
description: 通用文本「理解 → 重新组织表达 → 朗读」助手：支持网页 URL、本地 HTML、Markdown（.md）、纯文本（.txt）等多种来源，先由模型读懂内容、提炼主旨并按选定风格（通俗讲解/要点清单/深度解读等）重新组织表达，再用文本转语音（TTS）生成可收听的 mp3「有声解读版」，并可选同步生成字幕（SRT/LRC）与带字幕高亮同步的 HTML 播放器。当用户想把网页/文章/MD/TXT/HTML 内容读懂后用声音讲出来、做"有声解读"，或说「读声音」「朗读这篇」「用大白话讲这篇」「总结一下再读」「把内容重新组织后读出来」时使用。无头环境（无扬声器）下以生成 mp3 文件的方式交付。
version: 1.0.0
display_name: "智能阅读助手"
display_name_en: "Read Smart"
description_zh: "通用文本读懂·重组·朗读·字幕助手：支持网页、本地 HTML、Markdown、TXT 等来源，先理解再重组表达，用自然语音生成有声解读 mp3，并同步输出字幕与带字幕高亮同步的 HTML 播放器。"
description_en: "A universal text-to-audio digest assistant: understand and restructure web pages, local HTML, Markdown and TXT sources, then narrate them with natural TTS, producing an mp3 with synced subtitles (SRT/LRC) and a highlight-synced HTML player."
category: reading
author: "个人开发者"
---

# Read Smart（文本读懂 · 重组 · 朗读 · 字幕）

## Overview

本技能把任意**网页 URL**、**本地 HTML**、**Markdown（.md）** 或**纯文本（.txt）** 来源先"读懂"——由模型提炼主旨、重组结构、用更适合听觉的方式重新表达，再用 **Microsoft Edge 神经网络语音（edge-tts）** 合成为 **mp3 音频**，并可**同步生成字幕**（SRT / LRC）与**带字幕高亮同步的 HTML 播放器**，实现「读内容、读懂它、读声音、看字幕」。

它**不止于机械朗读**，而是先理解、再重新组织与表达；中文效果自然、免费、无需 API key。

## When to use

- 用户想"听懂"而不是"听读"某份内容：把网页 / MD / TXT / HTML 消化后再讲出来
- 用户说：「用大白话讲这篇」「总结一下再读」「把内容重新组织后读出来」「给我做个有声解读版」
- 用户给的是网页链接、本地 Markdown、TXT 或 HTML 文件，想转成音频
- 用户希望朗读时**文字同步显示**（字幕 / 高亮跟读）
- 用户想**固定使用某种声音 / 语速**（配置文件一劳永逸）
- 用户给的是 **WorkBuddy 资料库分享链接**（workbuddy.link/p/…），技能会自动提取真实正文
- 需要离线/本地生成音频，而不是依赖浏览器扩展

## 工作流（理解 + 朗读 两段式）

**阶段一：理解并重新组织表达（由加载本技能的模型完成）**
1. 读取内容：网页用 `read_smart.py --url "<url>"`；本地文件（HTML / MD / TXT）用 `read_smart.py "<路径>"`；或用 WebFetch 抓取网页正文。
2. 理解内容：识别主旨、核心论点、关键证据 / 数据、结论。
3. 重组表达：按 `references/reframe.md` 选择一种风格（通俗讲解 / 要点清单 / 深度解读 / 故事化 / 极简），
   重写为一段连贯、口语化、可直接朗读的文本。忠于原意、标注来源、去冗余。
4. （可选）先在对话中把重组稿给用户确认风格，再进入朗读。

**阶段二：朗读 + 字幕（由脚本完成）**
5. 把重组后的文本交给 TTS：
   ```bash
   python3 <skill_dir>/scripts/read_smart.py --text "重组后的文本..." --output out.mp3
   ```
   默认会同时生成 `out.srt`（字幕）与 `out.html`（带同步高亮字幕的播放器）。
6. 交付 mp3 / srt / html 路径给用户。

> 若用户只要"原样朗读、不做理解重组"，直接走旧流程：`read_smart.py "<url 或本地文件路径>"` 即可，字幕同样会生成。

## 用法

### 直接朗读（原样，不做理解）
```bash
python3 <skill_dir>/scripts/read_smart.py "https://example.com/article"
python3 <skill_dir>/scripts/read_smart.py ./page.html
python3 <skill_dir>/scripts/read_smart.py ./note.md
python3 <skill_dir>/scripts/read_smart.py ./article.txt
```

### 理解重组后朗读（核心用法）
```bash
# 1) 模型产出重组稿（写入文件或直接作为 --text 参数）
# 2) 朗读该文本（默认生成字幕 + HTML 播放器）
python3 <skill_dir>/scripts/read_smart.py --text-file reframed.txt --output audio.mp3
# 或直接传文本
python3 <skill_dir>/scripts/read_smart.py --text "今天这篇文章讲的是……" --output audio.mp3
```

### 指定声线 / 语速 / 音量
```bash
python3 <skill_dir>/scripts/read_smart.py --text "..." --voice zh-CN-YunyangNeural
python3 <skill_dir>/scripts/read_smart.py --text "..." --voice en-US-AriaNeural --rate "+10%" --volume "-5%"
```

### 用配置文件一劳永逸（语音做成配置参数）
新建 `config.json`（放在**技能目录**或 `~/.config/read-smart/config.json`，或直接用 `--config` 指定），示例见 `config.example.json`：
```json
{
  "voice": "zh-CN-YunyangNeural",
  "lang": "zh",
  "rate": "+5%",
  "volume": "+0%",
  "max_chars": 2000,
  "output_template": "{date}_{title}",
  "subtitle": true,
  "sub_format": "srt"
}
```
之后运行无需每次敲参数，命令行参数会**覆盖**配置文件中的同项：
```bash
python3 <skill_dir>/scripts/read_smart.py --text-file reframed.txt --config my_config.json
```

### 字幕与同步播放
- 默认（`subtitle: true`）会生成：
  - `xxx.srt` —— 标准字幕，可被 VLC / PotPlayer / 剪映等加载，与音频同步显示文字；
  - `xxx.html` —— **自带高亮同步播放器**：用浏览器打开即听到声音、看到当前句自动高亮并滚动，点击任意句可跳转（最直观的"字幕同步显示"）。
- 关闭字幕：`--no-subtitle`。
- 额外生成 LRC（适配音乐播放器）：`--sub-format both`（同时输出 SRT + LRC）。

### 输出文件命名
- 默认文件名由模板 `output_template` 决定，支持变量：`{title}` `{voice}` `{date}` `{lang}`。
- 默认模板 `{title}`（即文章标题）；可在配置或 `--name-template` 改为如 `{date}_{title}`、`{title}_{voice}` 等。
- 也可直接用 `--output` 指定完整 mp3 路径（最高优先级），其同名 `.srt` / `.html` 会自动派生。

## 参数速查

| 参数 | 含义 | 默认值（可被配置/命令行覆盖） |
| --- | --- | --- |
| 位置参数 `source` | 网页 URL，或本地 HTML / Markdown / TXT 路径（原样朗读） | 可选 |
| `--url` / `--file` | 同上，等价于位置参数 | — |
| `--text` | 直接传入要朗读的文本（理解重组后用） | — |
| `--text-file` | 读取文本文件作为朗读素材 | — |
| `--voice` | 语音名（见 references/voices.md） | `zh-CN-XiaoxiaoNeural` |
| `--lang` | 语言前缀，决定默认语音 | `zh` |
| `--rate` | 语速，如 `+10%` / `-5%` / `slow` / `fast` | 默认语速 |
| `--volume` | 音量，如 `+0%` / `-10%` / `loud` | 默认音量 |
| `--max-chars` | 每块合成文本最大字符数 | `2000` |
| `--output` | 输出 mp3 完整路径（最高优先级） | 由 `output_template` 决定 |
| `--name-template` | 命名模板 `{title}{voice}{date}{lang}` | `{title}` |
| `--subtitle` / `--no-subtitle` | 是否生成同步字幕 | 开 |
| `--sub-format` | 字幕格式 `srt` / `lrc` / `both` | `srt` |
| `--config` | JSON 配置文件路径 | 自动查找技能目录 / `~/.config/read-smart/` |
| `--no-install` | 依赖缺失时直接报错，不自动安装 | 关闭 |

## 依赖说明

- **运行时**：Python 3.9+；系统需有 `ffmpeg`（超长文本分片后拼接）。
- **Python 库**（首次运行自动安装）：`edge-tts`、`requests`、`beautifulsoup4`。
- **网络**：edge-tts 需联网；正文抓取需联网（本地文件除外）。
- **模型能力**："理解重组"由加载本技能的模型（LLM）完成，无需额外依赖。

## 内容重组参考

- 风格选择、重组流程、输出建议见 `references/reframe.md`。
- 更多声线见 `references/voices.md`。

## 注意事项与排查

- **无头环境无扬声器**：以生成 mp3 文件形式交付；用 `--output` 指定路径便于管理。
- **字幕同步**：`xxx.html` 播放器在浏览器打开即可看到字幕随声音高亮；`xxx.srt` 用于专业播放器。
- **理解质量**：重组效果取决于模型对原文的抓取；原文若反爬 / 动态渲染导致提取不全，
  可改用「Reader 模式」保存的 HTML，或先用 WebFetch 获取干净正文。
- **忠于原意**：重组时不要编造事实或数据；关键数字、结论、出处需保留并标注。
- **合成失败**：多为网络问题或语音名写错，检查 `--voice` 是否在 references/voices.md 列表内。
- **资料库分享链接**：`workbuddy.link/p/...` 或 `workbuddy.cn/space/...` 这类发布页是运行时渲染的壳，
  脚本会自动从页面里定位真实正文资源并提取（无需手动复制）。但**本地导出的资料库封装页**
  （仅含"WorkBuddy 资料库文档"几字）真实正文在服务端，需改用其**公开分享链接**或复制正文。

## 发布说明

- 打包：将技能目录（`SKILL.md`、`scripts/`、`references/`、`config.example.json`）压缩为 zip，zip 第一层直接是 `SKILL.md`。
- 重新上传前必须递增 `version`（平台不允许覆盖已记录版本）。
- 上传入口：open.workbuddy.cn/skill/publish
