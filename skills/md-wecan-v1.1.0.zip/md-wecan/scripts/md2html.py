#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
md2html.py —— Markdown 排版规范化渲染器（零第三方依赖）

一次编写，四种去向：
  web     完整阅读版 HTML（目录 / 章节编号 / 提示框 / 卡片 / 进度条）
  wechat  微信公众号稿：正文片段 + 全内联样式，可直接全选粘贴
  print   打印版 HTML：A4 分页、避免卡片断页，浏览器「打印为 PDF」即得成品
  poster  分享海报：定尺画布（默认 1080×1440），可截图导出 PNG

用法：
  python3 md2html.py input.md                      # 默认 web 版，输出同名 .html
  python3 md2html.py input.md --mode all           # 同时导出 web / wechat / print / poster
  python3 md2html.py input.md --theme ink          # 换主题（azure / ink / warm）
  python3 md2html.py input.md -o out/x.html --mode wechat
  python3 md2html.py input.md --mode poster --poster-ratio 4:5 --poster-png
  python3 md2html.py --themes                      # 查看可用主题
"""
import os
import re
import sys
import html
import argparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from theme import THEMES, DEFAULT_THEME, build_css, JS_PROGRESS, list_themes  # noqa: E402
from poster import build_poster, export_png, RATIOS as POSTER_RATIOS, LAYOUTS as POSTER_LAYOUTS  # noqa: E402

POSTER_MODES = ("web", "wechat", "print", "poster")

# ------------------------------------------------------------------ 语义映射
# GitHub 风格告警 → 配色
ALERT_TYPES = {
    "NOTE": "blue", "INFO": "blue", "ABSTRACT": "blue", "SUMMARY": "blue",
    "TIP": "green", "SUCCESS": "green", "CHECK": "green", "DONE": "green",
    "IMPORTANT": "gold", "QUESTION": "gold", "KEY": "gold", "IDEA": "gold",
    "WARNING": "red", "CAUTION": "red", "DANGER": "red", "BUG": "red", "FAIL": "red",
}
# emoji 前缀 → 配色（写给习惯用 emoji 的作者）
EMOJI_TYPES = [
    ("✅", "green"), ("🟢", "green"), ("✔", "green"), ("🎯", "green"),
    ("⚠", "red"), ("🚨", "red"), ("❌", "red"), ("🔴", "red"), ("⛔", "red"),
    ("💡", "gold"), ("🔑", "gold"), ("📌", "gold"), ("⚖", "gold"), ("💰", "gold"),
    ("🏢", "gold"), ("⭐", "gold"), ("🧠", "blue"), ("📖", "blue"), ("🧭", "blue"),
]
ALERT_LABEL = {
    "blue": "说明", "green": "要点", "gold": "关键", "red": "注意",
}
ENDING_WORDS = ("结语", "写在最后", "尾声", "小结", "后记", "总结")

BLOCK_START = re.compile(r"^(#{1,6}\s|>\s?|```|\||\s*[-*+]\s|\s*\d+[.)、]\s|<!--|\s*!\[)")


# ------------------------------------------------------------------ 工具函数
def strip_md(t: str) -> str:
    """去掉行内标记，用于字数统计与纯文本导出。"""
    t = re.sub(r"```.*?```", "", t, flags=re.S)
    t = re.sub(r"!\[[^\]]*\]\([^)]*\)", "", t)
    t = re.sub(r"\[([^\]]+)\]\([^)]*\)", r"\1", t)
    t = re.sub(r"[*_~`#>\-]{1,}", " ", t)
    return t


def count_stats(md: str):
    plain = strip_md(md)
    cjk = len(re.findall(r"[\u4e00-\u9fff]", plain))
    words = len(re.findall(r"[A-Za-z0-9]+", plain))
    total = cjk + words
    minutes = max(1, round(total / 400)) if total else 1
    return {"chars": total, "cjk": cjk, "minutes": minutes}


# 微信模式开关：为 True 时行内元素直接写 style（微信会剥离 style 标签与 class）
WX_MODE = False
WX_COLORS = {"strong": "#0b4f83", "em": "#b7791f"}
WX_INLINE_STYLE = {
    "a": "color:#576b95;text-decoration:none;",
    "code": ("background-color:rgba(0,0,0,0.06);color:#c7254e;font-size:14px;"
             "padding:2px 5px;border-radius:3px;font-family:Menlo,Consolas,monospace;"),
    "img": "max-width:100%;border-radius:8px;vertical-align:middle;",
}


def _wx_a_style():
    return ' style="%s"' % WX_INLINE_STYLE["a"] if WX_MODE else ' class="inline"'


def _wrap_code(text: str) -> str:
    code = html.escape(text)
    if WX_MODE:
        return "<code style=\"%s\">%s</code>" % (WX_INLINE_STYLE["code"], code)
    return '<code class="inline">%s</code>' % code


def _apply_emphasis(t: str) -> str:
    """加粗/斜体/删除线（不含链接与代码）。微信模式下颜色内联。"""
    st_em = ' style="color:%s;font-style:normal;font-weight:600;"' % WX_COLORS["em"] \
        if WX_MODE else ""
    st_st = ' style="color:%s;font-weight:700;"' % WX_COLORS["strong"] if WX_MODE else ""
    t = re.sub(r"\*\*\*(.+?)\*\*\*", r"<strong%s><em%s>\1</em></strong>" % (st_st, st_em), t)
    t = re.sub(r"\*\*(.+?)\*\*", r"<strong%s>\1</strong>" % st_st, t)
    t = re.sub(r"(?<![\*\w])\*([^*\n]+)\*(?!\*)", r"<em%s>\1</em>" % st_em, t)
    t = re.sub(r"~~(.+?)~~", r"<del>\1</del>", t)
    return t


def inline(t: str) -> str:
    """行内 Markdown → HTML。占位符保护已完成的片段，避免二次解析。"""
    t = html.escape(t, quote=False)
    stash = []

    def put(markup):
        stash.append(markup)
        return "\x00%d\x00" % (len(stash) - 1)

    # 1. 行内代码（最先处理，内容不再参与后续解析）
    t = re.sub(r"`([^`]+)`", lambda m: put(_wrap_code(m.group(1))), t)
    # 2. 行内图片
    img_attr = ' style="%s"' % WX_INLINE_STYLE["img"] if WX_MODE else \
        ' class="inline-img" loading="lazy"'
    t = re.sub(
        r"!\[([^\]]*)\]\(([^)\s]+)(?:\s+&quot;([^&]*)&quot;)?\)",
        lambda m: put('<img src="%s" alt="%s"%s>' % (m.group(2), m.group(1), img_attr)),
        t,
    )
    # 3. Markdown 链接（链接文字允许加粗等强调）
    a_style = _wx_a_style()
    t = re.sub(r"\[([^\]]+)\]\(([^)\s]+)\)",
               lambda m: put('<a href="%s"%s>%s</a>' % (m.group(2), a_style, _apply_emphasis(m.group(1)))),
               t)
    # 4. 裸链接（负向后顾避开 href=" 与已生成 <a> 文本前 的引号/斜杠）
    t = re.sub(r"(?<![\"'>=/])(https?://[^\s<>）)\]]+)",
               lambda m: put('<a href="%s"%s>%s</a>' % (m.group(1), a_style, m.group(1))),
               t)
    # 5. 强调
    t = _apply_emphasis(t)
    # 6. 还原占位
    return re.sub(r"\x00(\d+)\x00", lambda m: stash[int(m.group(1))], t)


def split_row(line: str):
    """按竖线拆行，支持 \\| 转义，避免单元格内含竖线时错列。"""
    s = line.strip()
    if s.startswith("|"):
        s = s[1:]
    if s.endswith("|") and not s.endswith("\\|"):
        s = s[:-1]
    return [p.replace("\\|", "|").strip() for p in re.split(r"(?<!\\)\|", s)]


def clean_title(t: str) -> str:
    """章节标题去掉 Markdown 标记与已有编号。"""
    t = re.sub(r"[*_`]", "", t).strip()
    m = re.match(r"^(\d{1,2})\s*[、.．:：)）]\s*(.+)$", t)
    if m and len(m.group(2)) > 1:
        return m.group(2).strip(), m.group(1).zfill(2)
    m = re.match(r"^第([一二三四五六七八九十百\d]+)[章节部分]\s*[、.：:]?\s*(.+)$", t)
    if m:
        return m.group(2).strip(), ""
    return t, ""


# ------------------------------------------------------------------ 解析层
def parse_frontmatter(text: str):
    """极简 YAML frontmatter（key: value / [a, b] / - item 列表）。"""
    meta = {}
    if not text.startswith("---"):
        return meta, text
    lines = text.split("\n")
    end = None
    for i in range(1, min(len(lines), 60)):
        if lines[i].strip() in ("---", "..."):
            end = i
            break
    if end is None:
        return meta, text
    body = lines[1:end]
    key = None
    for raw in body:
        if not raw.strip() or raw.strip().startswith("#"):
            continue
        m = re.match(r"^([A-Za-z_][\w-]*)\s*:\s*(.*)$", raw)
        if m:
            key, val = m.group(1).lower(), m.group(2).strip()
            if val.startswith("[") and val.endswith("]"):
                meta[key] = [v.strip().strip("\"'") for v in val[1:-1].split(",") if v.strip()]
            elif val == "":
                meta[key] = []
            else:
                meta[key] = val.strip("\"'")
        elif raw.strip().startswith("-") and key:
            if not isinstance(meta.get(key), list):
                meta[key] = []
            meta[key].append(raw.strip()[1:].strip().strip("\"'"))
    return meta, "\n".join(lines[end + 1:])


def parse_blocks(lines):
    """行扫描 → 块列表 (type, payload)。"""
    blocks, i, n = [], 0, len(lines)
    while i < n:
        line = lines[i]
        s = line.strip()

        if not s:
            i += 1
            continue

        # 注释：分页标记单独处理，其余丢弃
        if s.startswith("<!--"):
            if re.match(r"<!--\s*page-?break\s*-->", s, re.I):
                blocks.append(("pagebreak", None))
            i += 1
            continue

        # 围栏
        if s.startswith("```"):
            lang = s[3:].strip().lower()
            body, i = [], i + 1
            while i < n and not lines[i].strip().startswith("```"):
                body.append(lines[i].rstrip("\n"))
                i += 1
            i += 1
            if lang in ("grid", "cards"):
                blocks.append(("grid", body))
            elif lang in ("steps", "step"):
                blocks.append(("steps", body))
            elif lang in ("quote", "callout"):
                blocks.append(("quote", body))
            else:
                blocks.append(("code", (lang, body)))
            continue

        # 标题
        m = re.match(r"^(#{1,6})\s+(.*)$", s)
        if m:
            blocks.append(("h%d" % len(m.group(1)), m.group(2).strip()))
            i += 1
            continue

        # 引用 / 提示框
        if s.startswith(">"):
            body = []
            while i < n and lines[i].strip().startswith(">"):
                body.append(re.sub(r"^\s*>\s?", "", lines[i]).rstrip())
                i += 1
            blocks.append(("quote", body))
            continue

        # 表格
        if s.startswith("|") and i + 1 < n and re.match(r"^\|[\s:|-]+\|?\s*$", lines[i + 1].strip()):
            rows, aligns = [], []
            head_cells = split_row(s)
            sep_cells = split_row(lines[i + 1].strip())
            for c in sep_cells:
                if c.startswith(":") and c.endswith(":"):
                    aligns.append("center")
                elif c.endswith(":"):
                    aligns.append("right")
                else:
                    aligns.append("left")
            rows.append(head_cells)
            i += 2
            while i < n and lines[i].strip().startswith("|"):
                rows.append(split_row(lines[i].strip()))
                i += 1
            blocks.append(("table", (rows, aligns)))
            continue

        # 分隔线
        if re.match(r"^([-*_])\1{2,}$", s):
            blocks.append(("hr", None))
            i += 1
            continue

        # 列表（含缩进嵌套）
        if re.match(r"^[-*+]\s", s) or re.match(r"^\d+[.)、]\s", s):
            items, ordered = [], bool(re.match(r"^\d+[.)、]\s", s))
            base_indent = len(line) - len(line.lstrip())
            while i < n:
                cur = lines[i]
                cs = cur.strip()
                if not cs:
                    # 空行后仍属列表则继续
                    if i + 1 < n and (re.match(r"^\s*[-*+]\s", lines[i + 1]) or re.match(r"^\s*\d+[.)、]\s", lines[i + 1])):
                        i += 1
                        continue
                    break
                if re.match(r"^[-*+]\s", cs) or re.match(r"^\d+[.)、]\s", cs):
                    indent = len(cur) - len(cur.lstrip()) - base_indent
                    text = re.sub(r"^([-*+]|\d+[.)、])\s+", "", cs)
                    items.append((max(0, indent), text))
                    i += 1
                elif items and (len(cur) - len(cur.lstrip())) > base_indent:
                    # 续行并入上一项
                    items[-1] = (items[-1][0], items[-1][1] + " " + cs)
                    i += 1
                else:
                    break
            blocks.append(("ol" if ordered else "ul", items))
            continue

        # 独立图片
        m = re.match(r"^!\[([^\]]*)\]\(([^)\s]+)(?:\s+\"([^\"]*)\")?\)$", s)
        if m:
            blocks.append(("figure", (m.group(1), m.group(2))))
            i += 1
            continue

        # 段落
        body = []
        while i < n and lines[i].strip() and not BLOCK_START.match(lines[i].strip()):
            body.append(lines[i].strip())
            i += 1
        if body:
            blocks.append(("p", body))
        else:
            i += 1
    return blocks


def detect_callout(body):
    """判断引用块是否为提示框，返回 (type, title, lines)。"""
    if not body:
        return None
    first = body[0].strip()
    m = re.match(r"^\[!(\w+)\]\s*(.*)$", first)
    if m:
        kind = ALERT_TYPES.get(m.group(1).upper(), "blue")
        title = m.group(2).strip() or ALERT_LABEL[kind]
        return kind, title, body[1:]
    for emo, kind in EMOJI_TYPES:
        if first.startswith(emo):
            title = first[len(emo):].strip(" 　:：")
            return kind, (title or ALERT_LABEL[kind]), body[1:]
    return None


# ------------------------------------------------------------------ 渲染层
class Doc:
    def __init__(self, md, meta, theme, mode, opts):
        self.md = md
        self.meta = meta
        self.theme = theme
        self.mode = mode
        self.opts = opts
        self.stats = count_stats(md)

    # ---------- HTTP 片段 ----------
    def render_quote(self, body):
        co = detect_callout(body)
        if co:
            kind, title, rest = co
            inner = []
            for ln in rest:
                if ln.strip():
                    inner.append("<p>%s</p>" % inline(ln.strip()))
            return ('<div class="callout %s"><div class="co-title">%s</div>%s</div>'
                    % (kind, inline(title), "".join(inner)))
        paras = [p for p in re.split(r"\n\s*\n", "\n".join(body)) if p.strip()]
        return '<blockquote class="quote">%s</blockquote>' % "".join(
            "<p>%s</p>" % inline(p.replace("\n", " ").strip()) for p in paras)

    def render_list(self, items, ordered):
        if not items:
            return ""
        # 步骤卡判定：有序列表且每项以加粗开头
        if ordered and len(items) >= 2 and sum(1 for _, t in items if t.strip().startswith("**")) >= max(2, len(items) - 1):
            cards = []
            for idx, (_, t) in enumerate(items, 1):
                t = re.sub(r"^\*\*(.+?)\*\*\s*", "", t)
                head, desc = "", t
                m = re.match(r"^(.+?)[：:]\s*(.+)$", t)
                if m and len(m.group(1)) <= 24:
                    head, desc = m.group(1), m.group(2)
                out = ['<div class="step"><div class="step-n">%d</div>' % idx]
                if head:
                    out.append("<h5>%s</h5><p>%s</p>" % (inline(head), inline(desc)))
                else:
                    out.append("<p>%s</p>" % inline(desc))
                out.append("</div>")
                cards.append("".join(out))
            return '<div class="steps">%s</div>' % "".join(cards)

        def build(nodes):
            out = ["<%s class=\"plain\">" % ("ol" if ordered else "ul")]
            for text, kids in nodes:
                sub = build(kids) if kids else ""
                out.append("<li>%s%s</li>" % (inline(text), sub))
            out.append("</%s>" % ("ol" if ordered else "ul"))
            return "".join(out)

        def nest(items_list):
            """按缩进构建嵌套树：[(indent, text)] → [(text, [children])]。"""
            top = []
            st = [(-1, top)]
            for indent, text in items_list:
                while len(st) > 1 and indent <= st[-1][0]:
                    st.pop()
                kids = []
                st[-1][1].append((text, kids))
                st.append((indent, kids))
            return top

        return build(nest(items))

    def render_table(self, rows, aligns):
        if not rows:
            return ""
        ncol = len(rows[0])

        def pad(r):
            r = [(c or "") for c in r]
            return r + [""] * (ncol - len(r)) if len(r) < ncol else r[:ncol]

        def cell_style(i):
            a = aligns[i] if i < len(aligns) else "left"
            return ' style="text-align:%s;"' % a if a != "left" else ""

        head = pad(rows[0])
        o = ['<div class="table-wrap"><table><thead><tr>']
        o.append("".join("<th%s>%s</th>" % (cell_style(i), inline(c)) for i, c in enumerate(head)))
        o.append("</tr></thead><tbody>")
        for r in rows[1:]:
            r = pad(r)
            o.append("<tr>" + "".join("<td%s>%s</td>" % (cell_style(i), inline(c)) for i, c in enumerate(r)) + "</tr>")
        o.append("</tbody></table></div>")
        return "".join(o)

    def render_grid(self, lines):
        rows = [l.strip() for l in lines if l.strip() and not l.strip().startswith("#")]
        if not rows:
            return ""
        cls = "grid g2" if len(rows) > 3 and len(rows) % 2 == 0 else "grid"
        o = ['<div class="%s">' % cls]
        for i, r in enumerate(rows):
            parts = split_row(r)
            name = parts[0] if parts else ""
            tag = parts[1] if len(parts) > 1 else ""
            desc = "｜".join(parts[2:]) if len(parts) > 2 else ""
            o.append('<div class="gcard t%d">' % (i % 4 + 1))
            o.append('<div class="g-name">%s</div>' % inline(name))
            if tag:
                o.append('<div class="g-tag">%s</div>' % inline(tag))
            if desc:
                o.append("<p>%s</p>" % inline(desc))
            o.append("</div>")
        o.append("</div>")
        return "".join(o)

    def render_steps(self, lines):
        items = [(0, l.strip()) for l in lines if l.strip()]
        return self.render_list(items, True) if items else ""

    def render_code(self, lang, body):
        code = html.escape("\n".join(body))
        tag = '<span class="lang-tag">%s</span>' % html.escape(lang) if lang else ""
        return '<pre class="code">%s<code>%s</code></pre>' % (tag, code)

    def render_blocks(self, blocks):
        out = []
        for t, b in blocks:
            if t == "p":
                out.append("<p>%s</p>" % inline(" ".join(b)))
            elif t == "h3":
                out.append('<h3 class="sub">%s</h3>' % inline(b))
            elif t in ("h4", "h5", "h6"):
                out.append('<h4 class="minor">%s</h4>' % inline(b))
            elif t == "ul":
                out.append(self.render_list(b, False))
            elif t == "ol":
                out.append(self.render_list(b, True))
            elif t == "quote":
                out.append(self.render_quote(b))
            elif t == "table":
                out.append(self.render_table(*b))
            elif t == "grid":
                out.append(self.render_grid(b))
            elif t == "steps":
                out.append(self.render_steps(b))
            elif t == "code":
                out.append(self.render_code(*b))
            elif t == "figure":
                alt, src = b
                out.append('<figure><img src="%s" alt="%s" loading="lazy">%s</figure>'
                           % (html.escape(src), html.escape(alt),
                              "<figcaption>%s</figcaption>" % inline(alt) if alt else ""))
            elif t == "hr":
                out.append('<hr class="divider">')
            elif t == "pagebreak":
                out.append('<div class="pagebreak"></div>')
        return "\n".join(x for x in out if x)

    # ---------- 文档结构 ----------
    def structure(self):
        blocks = parse_blocks(self.md.replace("\r\n", "\n").split("\n"))
        title = self.meta.get("title") or ""
        subtitle = self.meta.get("subtitle") or ""
        h1 = ""
        idx = 0
        for i, (t, b) in enumerate(blocks):
            if t == "h1":
                if not title:
                    title = b
                elif not h1:
                    h1 = b
                idx = i + 1
                break
        blocks = blocks[idx:]
        if not title:
            title = self.opts.get("fallback_title") or "未命名文档"

        # hero 元信息：frontmatter 优先，其次首个引用块的 **键**：值
        chips, hero_quote = [], self.meta.get("quote") or ""
        for key, label in (("author", "作者"), ("source", "来源"), ("date", "日期"),
                           ("category", "分类"), ("column", "专栏")):
            v = self.meta.get(key)
            if isinstance(v, str) and v.strip():
                chips.append("%s：%s" % (label, v.strip()))
        tags = self.meta.get("tags") or []
        if isinstance(tags, str):
            tags = [t.strip() for t in re.split(r"[,，\s]+", tags) if t.strip()]
        chips.extend(tags)

        if blocks and blocks[0][0] == "quote" and not detect_callout(blocks[0][1]):
            meta_lines = blocks[0][1]
            used = False
            for ln in meta_lines:
                s = ln.strip()
                if not s:
                    continue
                m = re.match(r"^\*\*(核心命题|主旨|一句话|核心观点|导语|金句)\*\*[：:]\s*(.+)$", s)
                if m and not hero_quote:
                    hero_quote = m.group(2).strip()
                    used = True
                    continue
                m = re.match(r"^\*\*([^*：:]{1,8})\*\*[：:]\s*(.+)$", s)
                if m and not chips:
                    chips.append("%s：%s" % (m.group(1), m.group(2)))
                    used = True
                    continue
            if used:
                blocks = blocks[1:]

        # 分章
        chapters, pre, cur = [], [], None
        for t, b in blocks:
            if t == "h2":
                title_txt, num = clean_title(b)
                cur = {"num": num, "title": title_txt, "blocks": []}
                chapters.append(cur)
            elif cur is not None:
                cur["blocks"].append((t, b))
            else:
                pre.append((t, b))
        for i, c in enumerate(chapters, 1):
            if not c["num"]:
                c["num"] = "%02d" % i

        return dict(title=title, subtitle=subtitle, h1=h1, chips=chips,
                    hero_quote=hero_quote, chapters=chapters, pre=pre)

    # ---------- 主题切换 ----------
    def hero_kicker(self):
        return self.meta.get("kicker") or self.meta.get("column") or ""


# ------------------------------------------------------------------ web / print
def render_web(doc, for_print=False):
    st = doc.structure()
    opts = doc.opts
    parts = []

    # Hero：浅色渐变 + 系统色光斑，大标题走 SF Pro Display
    title = st["title"]
    kicker = doc.hero_kicker()
    st_meta = doc.stats
    hero = ['<header class="hero"><div class="hero-inner">']
    if kicker:
        hero.append('<span class="kicker">%s</span>' % inline(kicker))
    hero.append("<h1>%s</h1>" % inline(title))
    if st["subtitle"]:
        hero.append('<p class="subtitle">%s</p>' % inline(st["subtitle"]))
    if st["chips"]:
        hero.append('<div class="hero-meta">%s</div>' % "".join(
            "<span>%s</span>" % inline(c) for c in st["chips"]))
    if st["hero_quote"]:
        hero.append('<div class="hero-quote">“%s”</div>' % inline(st["hero_quote"]))
    hero.append('<div class="hero-stat"><span>约 %d 字</span><span>阅读约 %d 分钟</span>%s</div>'
                % (st_meta["chars"], st_meta["minutes"],
                   "<span>%d 个章节</span>" % len(st["chapters"]) if st["chapters"] else ""))
    hero.append("</div></header>")
    parts.append("".join(hero))

    # 正文：目录卡 + 章节卡片流
    body = ['<div class="page">']

    if st["chapters"] and len(st["chapters"]) >= 2 and not opts.get("no_toc"):
        toc = ['<nav class="toc"><div class="toc-title">Contents</div><ol>']
        for c in st["chapters"]:
            toc.append('<li><a href="#s%s"><span class="t-num">%s</span><span>%s</span></a></li>'
                       % (c["num"], c["num"], inline(c["title"])))
        toc.append("</ol></nav>")
        body.append("".join(toc))

    if st["pre"]:
        body.append('<section class="chapter-card reveal">%s</section>' % doc.render_blocks(st["pre"]))

    for c in st["chapters"]:
        anchor = "s" + c["num"]
        blks = list(c["blocks"])
        lede = ""
        if blks and blks[0][0] == "quote" and not detect_callout(blks[0][1]):
            lede = " ".join(x.strip() for x in blks[0][1] if x.strip())
            blks = blks[1:]
        content = doc.render_blocks(blks)
        is_end = any(w in c["title"] for w in ENDING_WORDS)
        if is_end:
            body.append('<section class="ending reveal" id="%s"><h3>%s</h3>%s</section>'
                        % (anchor, inline(c["title"]), content))
        else:
            head = ['<div class="ch-head"><div class="ch-no">%s</div>' % html.escape(c["num"])]
            head.append('<h2 class="ch-title">%s</h2>' % inline(c["title"]))
            if lede:
                head.append('<p class="ch-lede">%s</p>' % inline(lede))
            head.append("</div>")
            body.append('<section class="chapter-card reveal" id="%s">%s%s</section>'
                        % (anchor, "".join(head), content))

    colophon = doc.meta.get("colophon") or doc.meta.get("footer") or ""
    body.append('<div class="colophon">%s</div>' % (inline(colophon) if colophon
                else "本文由 MD工具助手 排版生成 · 内容版权归原作者所有"))
    body.append("</div>")

    scheme = opts.get("scheme") or "auto"
    css = build_css(doc.theme, scheme)
    is_dark = THEMES.get(doc.theme, THEMES[DEFAULT_THEME]).get("dark_vars") is None
    color_scheme = "dark" if (scheme == "dark" or (scheme == "auto" and is_dark)) else "light dark"
    has_js = not opts.get("no_js")
    overlay = ('<div class="progress" id="progress"></div>'
               '<div class="totop" id="totop">↑</div>') if has_js else ""
    script = "<script>%s</script>" % JS_PROGRESS if has_js else ""
    return (
        "<!DOCTYPE html>\n<html lang=\"zh-CN\">\n<head>\n<meta charset=\"UTF-8\">\n"
        "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n"
        "<meta name=\"color-scheme\" content=\"%s\">\n"
        "<title>%s</title>\n<style>%s</style>\n</head>\n<body>\n%s\n%s\n%s\n%s\n</body>\n</html>\n"
        % (color_scheme, html.escape(st["title"]), css, overlay,
           "\n".join(parts), "\n".join(body), script)
    )


# ------------------------------------------------------------------ wechat
def render_wechat(doc):
    """微信稿：不用 style 标签、不用 class，全部内联；表格/网格改纵向以适配手机。"""
    global WX_MODE, WX_COLORS
    st = doc.structure()
    # 微信正文背景固定为白，深色主题回落到浅色色板，保证可读
    theme_key = doc.theme
    if THEMES.get(theme_key, {}).get("dark_vars") is None:
        theme_key = DEFAULT_THEME
    t = THEMES.get(theme_key, THEMES[DEFAULT_THEME])["vars"]
    WX_MODE = True
    A, AD = t["--accent"], t["--accent-deep"]
    A_RGB = t["--accent-rgb"]
    INK, SOFT, FAINT = t["--text"], t["--text-2"], t["--text-3"]
    LINE = t["--line"]
    ORANGE, ORANGE_RGB = t["--orange"], t["--orange-rgb"]
    RED, RED_RGB = t["--red"], t["--red-rgb"]
    GREEN, GREEN_RGB = t["--green"], t["--green-rgb"]
    PAGE_BG = t["--bg"]
    WX_COLORS = {"strong": AD, "em": ORANGE}
    soft = lambda rgb, a: "rgba(%s,%s)" % (rgb, a)
    PALETTE = {
        "blue": (soft(A_RGB, .06), A, A),
        "gold": (soft(ORANGE_RGB, .08), ORANGE, ORANGE),
        "orange": (soft(ORANGE_RGB, .08), ORANGE, ORANGE),
        "red": (soft(RED_RGB, .07), RED, RED),
        "green": (soft(GREEN_RGB, .08), GREEN, GREEN),
    }
    MONO = "ui-monospace,SFMono-Regular,Menlo,Consolas,monospace"
    SANS = "-apple-system,BlinkMacSystemFont,'PingFang SC','Helvetica Neue',sans-serif"
    S = {
        "wrap": "font-size:16px;line-height:1.85;color:%s;letter-spacing:.3px;font-family:%s;" % (INK, SANS),
        "p": "margin:0 0 15px;font-size:16px;line-height:1.85;color:%s;letter-spacing:.3px;" % INK,
        "hero": "background-color:%s;padding:26px 22px;border-radius:14px;margin:0 0 26px;" % PAGE_BG,
        "kicker": "display:inline-block;font-size:11px;letter-spacing:1.5px;color:%s;font-family:%s;margin:0 0 12px;text-transform:uppercase;" % (SOFT, MONO),
        "h1": "margin:0 0 12px;font-size:22px;line-height:1.45;font-weight:700;color:%s;font-family:%s;letter-spacing:-.3px;" % (INK, SANS),
        "sub": "margin:0 0 14px;font-size:14.5px;line-height:1.75;color:%s;" % SOFT,
        "chip": "display:inline-block;font-size:12px;color:%s;background-color:#ffffff;border:1px solid %s;border-radius:999px;padding:3px 11px;margin:0 6px 6px 0;" % (SOFT, LINE),
        "quote_hero": "margin:16px 0 0;padding:12px 14px;background-color:%s;border-left:3px solid %s;border-radius:0 10px 10px 0;font-size:14.5px;line-height:1.75;color:%s;" % (soft(A_RGB, .06), A, INK),
        "stat": "margin:14px 0 0;font-size:12px;color:%s;font-family:%s;" % (FAINT, MONO),
        "ch_head": "margin:34px 0 16px;",
        "ch_num": "display:block;font-size:11px;letter-spacing:1.5px;color:%s;font-family:%s;font-weight:600;margin:0 0 7px;" % (A, MONO),
        "ch_title": "margin:0;padding:0 0 0 11px;border-left:4px solid %s;font-size:19px;line-height:1.45;font-weight:700;color:%s;letter-spacing:-.2px;" % (A, INK),
        "lede": "margin:11px 0 0;font-size:14.5px;line-height:1.8;color:%s;" % SOFT,
        "h3": "margin:26px 0 12px;padding:0 0 0 10px;border-left:3px solid %s;font-size:16.5px;line-height:1.5;font-weight:600;color:%s;" % (t["--teal"], INK),
        "li": "margin:0 0 8px;font-size:16px;line-height:1.85;color:%s;" % INK,
        "ul": "margin:0 0 15px;padding-left:22px;",
        "table_wrap": "margin:20px 0;overflow-x:auto;border:1px solid %s;border-radius:12px;" % LINE,
        "table": "width:100%;border-collapse:collapse;font-size:13.5px;line-height:1.7;",
        "th": "padding:10px 12px;background-color:%s;color:%s;border-bottom:1px solid %s;font-weight:600;text-align:left;font-size:12px;letter-spacing:.5px;" % (soft(A_RGB, .04), SOFT, LINE),
        "td": "padding:11px 12px;border-bottom:1px solid %s;color:%s;vertical-align:top;" % (LINE, INK),
        "code_wrap": "background-color:%s;border:1px solid %s;border-radius:12px;padding:14px 16px;margin:18px 0;" % (t["--code-bg"], LINE),
        "code": "margin:0;color:%s;font-size:12.5px;line-height:1.7;font-family:%s;white-space:pre-wrap;word-break:break-all;" % (t["--code-ink"], MONO),
        "card": "border:1px solid %s;border-radius:12px;padding:16px;margin:0 0 10px;background-color:#ffffff;" % LINE,
        "gname": "margin:0 0 4px;font-size:15px;font-weight:600;color:%s;" % INK,
        "gtag": "margin:0 0 7px;font-size:10.5px;color:%s;letter-spacing:1px;text-transform:uppercase;font-family:%s;" % (FAINT, MONO),
        "gdesc": "margin:0;font-size:13.5px;line-height:1.72;color:%s;" % SOFT,
        "step_n": "display:inline-block;width:22px;height:22px;line-height:22px;text-align:center;border-radius:50%%;background-color:%s;color:#ffffff;font-size:12.5px;font-weight:600;margin:0 9px 0 0;font-family:%s;" % (A, MONO),
        "ending": "background-color:%s;border:1px solid %s;border-radius:14px;padding:24px 20px;margin:12px 0 0;" % (soft(A_RGB, .06), soft(A_RGB, .14)),
        "colophon": "margin:30px 0 0;padding-top:16px;border-top:1px solid %s;font-size:12px;line-height:1.8;color:%s;text-align:center;" % (LINE, FAINT),
        "quote": "margin:18px 0;padding:14px 16px;background-color:%s;border-left:3px solid %s;border-radius:0 10px 10px 0;font-size:15px;line-height:1.8;color:%s;" % (soft(t["--teal-rgb"], .07), t["--teal"], INK),
        "hr": "border:none;border-top:1px solid %s;margin:28px 0;" % LINE,
    }

    def wx_blocks(blocks):
        out = []
        for typ, b in blocks:
            if typ == "p":
                out.append('<p style="%s">%s</p>' % (S["p"], inline(" ".join(b))))
            elif typ == "h3":
                out.append('<h3 style="%s">%s</h3>' % (S["h3"], inline(b)))
            elif typ in ("h4", "h5", "h6"):
                out.append('<p style="margin:20px 0 8px;font-size:15px;font-weight:700;color:%s;">%s</p>'
                           % (AD, inline(b)))
            elif typ in ("ul", "ol"):
                ordered = typ == "ol"
                is_steps = ordered and len(b) >= 2 and all(x.strip().startswith("**") for _, x in b)
                if is_steps:
                    for idx, (_, text) in enumerate(b, 1):
                        text = re.sub(r"^\*\*(.+?)\*\*\s*", "", text.strip())
                        out.append('<section style="%s">' % S["card"])
                        out.append('<p style="margin:0;font-size:15px;line-height:1.8;color:%s;"><span style="%s">%d</span>%s</p>'
                                   % (INK, S["step_n"], idx, inline(text)))
                        out.append("</section>")
                else:
                    tag = "ol" if ordered else "ul"
                    out.append('<%s style="%s">' % (tag, S["ul"]))
                    for _, text in b:
                        out.append('<li style="%s">%s</li>' % (S["li"], inline(text)))
                    out.append("</%s>" % tag)
            elif typ == "quote":
                co = detect_callout(b)
                if co:
                    kind, title, rest = co
                    bg, bd, fg = PALETTE.get(kind, PALETTE["blue"])
                    out.append('<section style="background-color:%s;border-left:4px solid %s;border-radius:8px;padding:14px 16px;margin:18px 0;">' % (bg, bd))
                    out.append('<p style="margin:0 0 6px;font-size:14.5px;font-weight:700;color:%s;">%s</p>' % (fg, inline(title)))
                    for ln in rest:
                        if ln.strip():
                            out.append('<p style="margin:0;font-size:14.5px;line-height:1.85;color:%s;">%s</p>' % (INK, inline(ln.strip())))
                    out.append("</section>")
                else:
                    txt = "".join('<p style="margin:0 0 6px;">%s</p>' % inline(x.strip()) for x in b if x.strip())
                    out.append('<blockquote style="%s">%s</blockquote>' % (S["quote"], txt))
            elif typ == "table":
                rows, aligns = b
                ncol = len(rows[0])
                out.append('<section style="%s"><table style="%s"><thead><tr>' % (S["table_wrap"], S["table"]))
                for c in rows[0]:
                    out.append('<th style="%s">%s</th>' % (S["th"], inline(c)))
                out.append("</tr></thead><tbody>")
                for r in rows[1:]:
                    r = (r + [""] * ncol)[:ncol]
                    out.append("<tr>" + "".join('<td style="%s">%s</td>' % (S["td"], inline(c)) for c in r) + "</tr>")
                out.append("</tbody></table></section>")
            elif typ == "grid":
                rows = [l.strip() for l in b if l.strip()]
                for r in rows:
                    parts = split_row(r)
                    name = parts[0] if parts else ""
                    tag = parts[1] if len(parts) > 1 else ""
                    desc = "｜".join(parts[2:]) if len(parts) > 2 else ""
                    out.append('<section style="%s">' % S["card"])
                    out.append('<p style="%s">%s</p>' % (S["gname"], inline(name)))
                    if tag:
                        out.append('<p style="%s">%s</p>' % (S["gtag"], inline(tag)))
                    if desc:
                        out.append('<p style="%s">%s</p>' % (S["gdesc"], inline(desc)))
                    out.append("</section>")
            elif typ == "steps":
                for idx, l in enumerate([x for x in b if x.strip()], 1):
                    text = re.sub(r"^\*\*(.+?)\*\*\s*", "", l.strip())
                    out.append('<section style="%s">' % S["card"])
                    out.append('<p style="margin:0;font-size:15px;line-height:1.8;color:%s;"><span style="%s">%d</span>%s</p>'
                               % (INK, S["step_n"], idx, inline(text)))
                    out.append("</section>")
            elif typ == "code":
                lang, body = b
                out.append('<section style="%s"><pre style="%s">%s</pre></section>'
                           % (S["code_wrap"], S["code"], html.escape("\n".join(body))))
            elif typ == "figure":
                alt, src = b
                out.append('<section style="margin:18px 0;"><img src="%s" alt="%s" style="width:100%%;border-radius:8px;display:block;">' % (html.escape(src), html.escape(alt)))
                if alt:
                    out.append('<p style="margin:8px 0 0;font-size:12.5px;color:%s;text-align:center;">%s</p>' % (SOFT, inline(alt)))
                out.append("</section>")
            elif typ == "hr":
                out.append('<hr style="%s">' % S["hr"])
        return "\n".join(out)

    # hero
    out = ['<section style="%s">' % S["wrap"]]
    out.append('<section style="%s">' % S["hero"])
    if doc.hero_kicker():
        out.append('<p style="%s">%s</p>' % (S["kicker"], inline(doc.hero_kicker())))
    out.append('<h1 style="%s">%s</h1>' % (S["h1"], inline(st["title"])))
    if st["subtitle"]:
        out.append('<p style="%s">%s</p>' % (S["sub"], inline(st["subtitle"])))
    if st["chips"]:
        out.append("".join('<span style="%s">%s</span>' % (S["chip"], inline(c)) for c in st["chips"]))
    if st["hero_quote"]:
        out.append('<p style="%s">“%s”</p>' % (S["quote_hero"], inline(st["hero_quote"])))
    out.append('<p style="%s">约 %d 字 · 阅读约 %d 分钟</p>' % (S["stat"], doc.stats["chars"], doc.stats["minutes"]))
    out.append("</section>")

    if st["pre"]:
        out.append(wx_blocks(st["pre"]))
    for c in st["chapters"]:
        blks = list(c["blocks"])
        lede = ""
        if blks and blks[0][0] == "quote" and not detect_callout(blks[0][1]):
            lede = " ".join(x.strip() for x in blks[0][1] if x.strip())
            blks = blks[1:]
        is_end = any(w in c["title"] for w in ENDING_WORDS)
        if is_end:
            out.append('<section style="%s">' % S["ending"])
            out.append('<p style="margin:0 0 12px;font-size:16px;font-weight:700;color:%s;">%s</p>' % (AD, inline(c["title"])))
            out.append(wx_blocks(blks))
            out.append("</section>")
        else:
            out.append('<section style="%s">' % S["ch_head"])
            out.append('<p style="%s">%s</p>' % (S["ch_num"], c["num"]))
            out.append('<h2 style="%s">%s</h2>' % (S["ch_title"], inline(c["title"])))
            if lede:
                out.append('<p style="%s">%s</p>' % (S["lede"], inline(lede)))
            out.append("</section>")
            out.append(wx_blocks(blks))

    colophon = doc.meta.get("colophon") or doc.meta.get("footer") or ""
    out.append('<p style="%s">%s</p>' % (S["colophon"], inline(colophon) if colophon else "本文由 MD工具助手 排版生成 · 内容版权归原作者所有"))
    out.append("</section>")
    html_out = "\n".join(out)
    WX_MODE = False
    return html_out


# ------------------------------------------------------------------ 入口
def build(md_text, theme=DEFAULT_THEME, mode="web", opts=None):
    opts = opts or {}
    meta, body = parse_frontmatter(md_text)
    # 优先级：命令行显式指定 > frontmatter > 默认
    meta_theme = meta.get("theme") if isinstance(meta.get("theme"), str) else ""
    theme = opts.pop("theme_override", None) or meta_theme or theme
    if theme not in THEMES:
        theme = DEFAULT_THEME
    doc = Doc(body, meta, theme, mode, opts)
    if mode == "wechat":
        return render_wechat(doc)
    if mode == "poster":
        return build_poster(doc.structure(), meta, theme,
                            opts.get("ratio") or "3:4", opts.get("layout") or "cover")
    return render_web(doc, for_print=(mode == "print"))


def main():
    ap = argparse.ArgumentParser(description="Markdown → 规范化 HTML（web / wechat / print / poster）")
    ap.add_argument("input", nargs="?", help="Markdown 文件路径")
    ap.add_argument("-o", "--output", help="输出 HTML 路径（默认同名）")
    ap.add_argument("--mode", default="web", help="web | wechat | print | poster | all")
    ap.add_argument("--theme", default=DEFAULT_THEME, help="azure | ink | warm")
    ap.add_argument("--scheme", default="auto", help="auto | light | dark（深色模式策略）")
    ap.add_argument("--no-toc", action="store_true", help="不生成目录")
    ap.add_argument("--no-js", action="store_true", help="去掉进度条脚本")
    ap.add_argument("--poster-ratio", default="3:4", help="海报比例：" + " | ".join(POSTER_RATIOS))
    ap.add_argument("--poster-layout", default="cover", help="海报版式：" + " | ".join(POSTER_LAYOUTS))
    ap.add_argument("--poster-png", action="store_true", help="海报同时截图为 PNG（需本机浏览器）")
    ap.add_argument("--themes", action="store_true", help="列出可用主题")
    args = ap.parse_args()

    if args.themes:
        for k, label, desc in list_themes():
            print("- %-6s %-14s %s" % (k, label, desc))
        return

    if not args.input:
        ap.print_help()
        sys.exit(1)

    path = os.path.abspath(args.input)
    if not os.path.exists(path):
        print("找不到文件：%s" % path)
        sys.exit(1)
    md_text = open(path, encoding="utf-8").read()

    stem = os.path.splitext(path)[0]
    opts = {"no_toc": args.no_toc, "no_js": args.no_js,
            "scheme": args.scheme,
            "ratio": args.poster_ratio, "layout": args.poster_layout,
            "fallback_title": os.path.basename(stem),
            "theme_override": args.theme if args.theme != DEFAULT_THEME else None}

    modes = list(POSTER_MODES) if args.mode == "all" else [args.mode]
    outputs = []
    for m in modes:
        if m not in POSTER_MODES:
            print("未知模式：%s" % m)
            sys.exit(1)
        out = build(md_text, args.theme, m, dict(opts))
        if args.output and len(modes) == 1:
            dst = args.output
        elif m == "web":
            dst = stem + ".html"
        else:
            dst = "%s.%s.html" % (stem, m)
        os.makedirs(os.path.dirname(os.path.abspath(dst)), exist_ok=True)
        with open(dst, "w", encoding="utf-8", newline="\n") as f:
            f.write(out)
        outputs.append((m, dst, len(out)))

    if args.poster_png:
        for m, dst, _ in outputs:
            if m != "poster":
                continue
            png = os.path.splitext(dst)[0] + ".png"
            got = export_png(dst, png, args.poster_ratio)
            if got:
                print("[png] %s" % got)
            else:
                print("[png] 未找到本机浏览器（Chrome / Edge / Chromium），已跳过截图；"
                      "可用浏览器打开海报 HTML 后手动截图。")

    stats = count_stats(md_text)
    for m, dst, size in outputs:
        print("[%s] %s  (%d 字节)" % (m, dst, size))
    print("统计：约 %d 字 · 阅读约 %d 分钟" % (stats["chars"], stats["minutes"]))


if __name__ == "__main__":
    main()
