# DSH 本体库专家团 · dsh-onto-team

> 基于 Deepseek Harness 框架，快速搭建安全、可控的本体库数据仓库底座，挖掘数据价值、提升业务效能。

一个 1 主理人 + 5 团员的 Team 型专家团，覆盖本体库建设的完整链路。

## 团队分工

| 角色 | agent | 职责 | 交付物 |
|---|---|---|---|
| ONTO主理人 | `dsh-onto-wecan` | 需求澄清、任务拆解分派、成果汇总、兜底 | 六段式最终方案 |
| 业务专家 | `dsh-onto-metric` | 指标拆解、口径定义、指标↔本体映射 | 指标字典 + 映射表 |
| 静态本体架构师 | `dsh-onto-base` | 类/属性/关系/约束建模 | OWL/JSON-LD + 建模说明 |
| 动态本体执行 | `dsh-onto-flow` | 接入管道、增量更新、版本治理、冲突消解 | 演化规则 + 数据流图 |
| 问数专家 | `dsh-onto-qa` | NL→SPARQL/Cypher、查询模板、语义校验 | 问法↔语句对照表 |
| 可视化专家 | `dsh-onto-viz` | 布局选型、视觉编码、图表配置 | 可运行配置代码 |

> 上表是**通用契约**。各团员在 `agents/*.md` 的「本项目默认约定（dsh-java）」小节中
> 定义了面向 dsh-java 工程的具体落地形态（如 schema 输出 YAML+DDL、问数主用 NL2SQL 等），
> 仅在该项目上下文下生效，不改变对外契约。

## 协作链路

```
业务诉求 → ONTO主理人 拆解
   ├─ 口径  → @dsh-onto-metric   （要量什么）
   ├─ 建模  → @dsh-onto-base     （怎么表达）
   ├─ 演化  → @dsh-onto-flow     （怎么长）
   ├─ 问数  → @dsh-onto-qa       （怎么取）
   ├─ 展示  → @dsh-onto-viz      （怎么看）
   └─ 汇总 → ONTO主理人统一交付
```

## 适用场景

- 从零设计一个领域本体库（如博弈论知识库、企业主数据、供应链关系网络）
- 把已有指标体系映射成本体模型并设计更新机制
- 让业务方能自然语言问数、并把结果可视化呈现
- 本体库的安全管控与版本治理方案设计

## 目录结构

```
dsh-onto-team/
├── .codebuddy-plugin/plugin.json
├── settings.json
├── agents/
│   ├── dsh-onto-wecan.md
│   ├── dsh-onto-metric.md
│   ├── dsh-onto-base.md
│   ├── dsh-onto-flow.md
│   ├── dsh-onto-qa.md
│   └── dsh-onto-viz.md
├── avatars/
└── README.md
```

## 使用

安装后在专家中心「我的专家 → 专家团」中选择 **DSH 本体库专家团**，点击召唤即可。
