#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
theme.py —— MD工具助手（md-wecan）视觉主题（Apple / iOS-macOS 设计语言）

设计原则
  1. 系统色板：iOS 系统色（systemBlue / systemTeal / systemGreen / systemOrange / systemRed），
     不自定义高饱和颜色，保证浅色与深色模式下都成立。
  2. 材质层级：背景 / 卡片 / 内嵌块三级材质，用「背景色差 + 极轻描边 + 多层柔和阴影」
     表达层次，而不是用重边框和深色分割线。
  3. 连续圆角：卡片 22px、内嵌块 14px、胶囊 999px，与 macOS / iOS 的连续曲率视觉一致。
  4. 字体：SF Pro 优先（-apple-system），中文回落苹方；数字与标签用 SF Mono + tabular-nums。
  5. 深色模式：azure / warm 提供 dark 变体，跟随系统或强制切换；ink 本身即深色主题。

三套主题
  azure  iOS 浅色（默认）  — 系统蓝 + 青，白卡浮于浅灰背景
  ink    iOS 深色        — 纯黑背景 + 抬升的 #1C1C1E 卡片，系统蓝提亮
  warm   iOS 浅暖        — 米白背景 + 赭石强调，适合随笔与长文
"""

# ---------------------------------------------------------------- 主题定义
THEMES = {
    "azure": {
        "label": "iOS 浅色（默认）",
        "desc": "系统蓝 + 青，白卡浮于浅灰背景，层次最接近 macOS 原生应用。",
        "vars": {
            "--bg": "#F2F2F7",
            "--bg-elev": "#FFFFFF",
            "--bg-elev-2": "#FFFFFF",
            "--bg-inset": "rgba(120,120,128,0.08)",
            "--bg-inset-2": "rgba(120,120,128,0.12)",
            "--text": "#1C1C1E",
            "--text-2": "rgba(60,60,67,0.62)",
            "--text-3": "rgba(60,60,67,0.34)",
            "--line": "rgba(60,60,67,0.10)",
            "--line-strong": "rgba(60,60,67,0.18)",
            "--accent": "#007AFF",
            "--accent-deep": "#0060DF",
            "--accent-rgb": "0,122,255",
            "--teal": "#30B0C7",
            "--teal-rgb": "48,176,199",
            "--green": "#248A3D",
            "--green-rgb": "52,199,89",
            "--orange": "#B25000",
            "--orange-rgb": "255,149,0",
            "--red": "#D70015",
            "--red-rgb": "255,59,48",
            "--indigo": "#3634A3",
            "--indigo-rgb": "88,86,214",
            "--hero-1": "#FFFFFF",
            "--hero-2": "#F2F2F7",
            "--code-bg": "#F5F5F7",
            "--code-ink": "#1C1C1E",
            "--shadow-1": "0 1px 2px rgba(0,0,0,.04), 0 1px 1px rgba(0,0,0,.02)",
            "--shadow-2": "0 2px 6px rgba(0,0,0,.05), 0 10px 30px -8px rgba(0,0,0,.10)",
            "--shadow-3": "0 12px 40px -12px rgba(0,0,0,.22), 0 2px 8px rgba(0,0,0,.06)",
            "--radius-xs": "8px",
            "--radius-s": "12px",
            "--radius-m": "16px",
            "--radius-l": "22px",
            "--radius-xl": "28px",
        },
        "dark_vars": {
            "--bg": "#000000",
            "--bg-elev": "#1C1C1E",
            "--bg-elev-2": "#2C2C2E",
            "--bg-inset": "rgba(120,120,128,0.20)",
            "--bg-inset-2": "rgba(120,120,128,0.28)",
            "--text": "#FFFFFF",
            "--text-2": "rgba(235,235,245,0.60)",
            "--text-3": "rgba(235,235,245,0.32)",
            "--line": "rgba(255,255,255,0.10)",
            "--line-strong": "rgba(255,255,255,0.18)",
            "--accent": "#0A84FF",
            "--accent-deep": "#409CFF",
            "--accent-rgb": "10,132,255",
            "--teal": "#40C8E0",
            "--teal-rgb": "64,200,224",
            "--green": "#30D158",
            "--green-rgb": "48,209,88",
            "--orange": "#FF9F0A",
            "--orange-rgb": "255,159,10",
            "--red": "#FF453A",
            "--red-rgb": "255,69,58",
            "--indigo": "#7D7AFF",
            "--indigo-rgb": "125,122,255",
            "--hero-1": "#0A0A0C",
            "--hero-2": "#000000",
            "--code-bg": "#1C1C1E",
            "--code-ink": "#E5E5EA",
            "--shadow-1": "0 1px 2px rgba(0,0,0,.5)",
            "--shadow-2": "0 2px 8px rgba(0,0,0,.55), 0 12px 32px -10px rgba(0,0,0,.7)",
            "--shadow-3": "0 12px 44px -12px rgba(0,0,0,.8)",
        },
    },
    "ink": {
        "label": "iOS 深色",
        "desc": "纯黑背景 + #1C1C1E 卡片，系统蓝提亮，适合夜间阅读与深度长文。",
        "vars": {
            "--bg": "#000000",
            "--bg-elev": "#1C1C1E",
            "--bg-elev-2": "#2C2C2E",
            "--bg-inset": "rgba(120,120,128,0.20)",
            "--bg-inset-2": "rgba(120,120,128,0.28)",
            "--text": "#FFFFFF",
            "--text-2": "rgba(235,235,245,0.60)",
            "--text-3": "rgba(235,235,245,0.32)",
            "--line": "rgba(255,255,255,0.10)",
            "--line-strong": "rgba(255,255,255,0.18)",
            "--accent": "#0A84FF",
            "--accent-deep": "#409CFF",
            "--accent-rgb": "10,132,255",
            "--teal": "#40C8E0",
            "--teal-rgb": "64,200,224",
            "--green": "#30D158",
            "--green-rgb": "48,209,88",
            "--orange": "#FF9F0A",
            "--orange-rgb": "255,159,10",
            "--red": "#FF453A",
            "--red-rgb": "255,69,58",
            "--indigo": "#7D7AFF",
            "--indigo-rgb": "125,122,255",
            "--hero-1": "#0A0A0C",
            "--hero-2": "#000000",
            "--code-bg": "#2C2C2E",
            "--code-ink": "#E5E5EA",
            "--shadow-1": "0 1px 2px rgba(0,0,0,.5)",
            "--shadow-2": "0 2px 8px rgba(0,0,0,.55), 0 12px 32px -10px rgba(0,0,0,.7)",
            "--shadow-3": "0 12px 44px -12px rgba(0,0,0,.8)",
            "--radius-xs": "8px",
            "--radius-s": "12px",
            "--radius-m": "16px",
            "--radius-l": "22px",
            "--radius-xl": "28px",
        },
        "dark_vars": None,
    },
    "warm": {
        "label": "iOS 浅暖",
        "desc": "米白背景 + 赭石强调，柔和不刺眼，适合随笔、读书笔记与分享稿。",
        "vars": {
            "--bg": "#F6F4F0",
            "--bg-elev": "#FFFDF9",
            "--bg-elev-2": "#FFFDF9",
            "--bg-inset": "rgba(140,120,95,0.09)",
            "--bg-inset-2": "rgba(140,120,95,0.14)",
            "--text": "#2A2521",
            "--text-2": "rgba(60,50,40,0.62)",
            "--text-3": "rgba(60,50,40,0.34)",
            "--line": "rgba(60,50,40,0.10)",
            "--line-strong": "rgba(60,50,40,0.18)",
            "--accent": "#B4652A",
            "--accent-deep": "#8E4C1D",
            "--accent-rgb": "180,101,42",
            "--teal": "#5E7A6B",
            "--teal-rgb": "94,122,107",
            "--green": "#3D6B4A",
            "--green-rgb": "61,107,74",
            "--orange": "#A25A00",
            "--orange-rgb": "162,90,0",
            "--red": "#B3261E",
            "--red-rgb": "179,38,30",
            "--indigo": "#5B5480",
            "--indigo-rgb": "91,84,128",
            "--hero-1": "#FFFDF9",
            "--hero-2": "#F6F4F0",
            "--code-bg": "#F3EFE8",
            "--code-ink": "#2A2521",
            "--shadow-1": "0 1px 2px rgba(80,60,30,.05), 0 1px 1px rgba(80,60,30,.03)",
            "--shadow-2": "0 2px 6px rgba(80,60,30,.06), 0 10px 30px -8px rgba(80,60,30,.12)",
            "--shadow-3": "0 12px 40px -12px rgba(80,60,30,.24), 0 2px 8px rgba(80,60,30,.07)",
            "--radius-xs": "8px",
            "--radius-s": "12px",
            "--radius-m": "16px",
            "--radius-l": "22px",
            "--radius-xl": "28px",
        },
        "dark_vars": {
            "--bg": "#000000",
            "--bg-elev": "#1C1A18",
            "--bg-elev-2": "#2C2825",
            "--bg-inset": "rgba(140,120,95,0.22)",
            "--bg-inset-2": "rgba(140,120,95,0.30)",
            "--text": "#F7F3EC",
            "--text-2": "rgba(247,243,236,0.62)",
            "--text-3": "rgba(247,243,236,0.32)",
            "--line": "rgba(255,250,240,0.10)",
            "--line-strong": "rgba(255,250,240,0.18)",
            "--accent": "#E08B4A",
            "--accent-deep": "#F0A468",
            "--accent-rgb": "224,139,74",
            "--teal": "#8CA997",
            "--teal-rgb": "140,169,151",
            "--green": "#4C8A5C",
            "--green-rgb": "76,138,92",
            "--orange": "#E09A3A",
            "--orange-rgb": "224,154,58",
            "--red": "#E4604F",
            "--red-rgb": "228,96,79",
            "--indigo": "#8E85B8",
            "--indigo-rgb": "142,133,184",
            "--hero-1": "#0A0908",
            "--hero-2": "#000000",
            "--code-bg": "#1C1A18",
            "--code-ink": "#F0EBE3",
            "--shadow-1": "0 1px 2px rgba(0,0,0,.5)",
            "--shadow-2": "0 2px 8px rgba(0,0,0,.55), 0 12px 32px -10px rgba(0,0,0,.7)",
            "--shadow-3": "0 12px 44px -12px rgba(0,0,0,.8)",
        },
    },
}

DEFAULT_THEME = "azure"

# ---------------------------------------------------------------- 基础样式
BASE_CSS = """
* { margin: 0; padding: 0; box-sizing: border-box; }
html { scroll-behavior: smooth; -webkit-text-size-adjust: 100%; }
body {
  font-family: var(--sans);
  background: var(--bg);
  color: var(--text);
  line-height: 1.78;
  font-size: 17px;
  letter-spacing: .01em;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  font-variant-numeric: tabular-nums;
  text-rendering: optimizeLegibility;
}
.page { max-width: 900px; margin: 0 auto; padding: 0 22px 100px; }

/* ────────────────────────────── Hero ────────────────────────────── */
.hero {
  position: relative;
  overflow: hidden;
  padding: clamp(72px, 11vw, 130px) 22px clamp(48px, 7vw, 76px);
  background:
    radial-gradient(ellipse 65% 55% at 10% -12%, rgba(var(--accent-rgb),.16), transparent 68%),
    radial-gradient(ellipse 55% 50% at 94% 0%, rgba(var(--teal-rgb),.14), transparent 70%),
    linear-gradient(180deg, var(--hero-1) 0%, var(--hero-2) 100%);
  border-bottom: 1px solid var(--line);
}
.hero-inner { max-width: 900px; margin: 0 auto; position: relative; }
.hero .kicker {
  display: inline-flex; align-items: center; gap: 9px;
  font-family: var(--mono); font-size: 12px; font-weight: 500;
  letter-spacing: .06em; text-transform: uppercase;
  color: var(--text-2);
  background: rgba(var(--accent-rgb),.08);
  border: 1px solid rgba(var(--accent-rgb),.18);
  -webkit-backdrop-filter: blur(20px) saturate(180%);
  backdrop-filter: blur(20px) saturate(180%);
  border-radius: 999px; padding: 7px 15px; margin-bottom: 26px;
}
.hero .kicker::before {
  content: ""; width: 6px; height: 6px; border-radius: 50%;
  background: var(--accent); flex: 0 0 auto;
}
.hero h1 {
  font-family: var(--display);
  font-size: clamp(32px, 5.6vw, 54px);
  font-weight: 700;
  line-height: 1.14;
  letter-spacing: -.022em;
  margin-bottom: 20px;
  max-width: min(19em, 100%);
  color: var(--text);
}
.hero .subtitle {
  font-size: clamp(16px, 2vw, 19px);
  line-height: 1.68;
  color: var(--text-2);
  max-width: min(38em, 100%);
  margin-bottom: 34px;
  font-weight: 400;
}
.hero-meta { display: flex; flex-wrap: wrap; gap: 9px; }
.hero-meta span {
  font-size: 13px; font-weight: 500;
  color: var(--text-2);
  background: var(--bg-elev);
  border: 1px solid var(--line);
  border-radius: 999px; padding: 6px 14px;
  box-shadow: var(--shadow-1);
}
.hero-quote {
  margin-top: 34px; padding: 18px 22px;
  border-left: 3px solid var(--accent);
  background: rgba(var(--accent-rgb),.05);
  border-radius: 0 var(--radius-m) var(--radius-m) 0;
  font-size: clamp(16px, 2vw, 18px);
  line-height: 1.7;
  color: var(--text);
  max-width: min(40em, 100%);
}
.hero-stat {
  margin-top: 30px; padding-top: 20px;
  border-top: 1px solid var(--line);
  display: flex; flex-wrap: wrap; gap: 26px;
  font-family: var(--mono); font-size: 12.5px; letter-spacing: .02em;
  color: var(--text-3);
}
.hero-stat b { color: var(--text-2); font-weight: 600; }

/* ────────────────────────────── 目录 ────────────────────────────── */
.toc {
  background: var(--bg-elev);
  border: 1px solid var(--line);
  border-radius: var(--radius-l);
  padding: 8px 6px;
  margin: -34px 0 34px;
  box-shadow: var(--shadow-2);
  position: relative;
  z-index: 2;
}
.toc-title {
  font-size: 12px; font-weight: 600; letter-spacing: .08em; text-transform: uppercase;
  color: var(--text-3); padding: 16px 20px 10px;
  font-family: var(--mono);
}
.toc ol { list-style: none; }
.toc li + li { border-top: 1px solid var(--line); }
.toc li a {
  display: flex; align-items: baseline; gap: 14px;
  text-decoration: none; color: var(--text);
  padding: 13px 20px; border-radius: var(--radius-s);
  transition: background .2s cubic-bezier(.4,0,.2,1);
  font-size: 15.5px; line-height: 1.5;
}
.toc li a:hover { background: var(--bg-inset); }
.toc .t-num {
  font-family: var(--mono); font-size: 12.5px; font-weight: 600;
  color: var(--accent); min-width: 22px; letter-spacing: .02em;
}

/* ────────────────────────────── 章节卡片 ────────────────────────────── */
.chapter-card {
  position: relative;
  background: var(--bg-elev);
  border: 1px solid var(--line);
  border-radius: var(--radius-l);
  padding: clamp(30px, 4.4vw, 52px) clamp(24px, 4.4vw, 54px);
  margin: 0 0 26px;
  box-shadow: var(--shadow-2);
  scroll-margin-top: 28px;
}
.ch-head { margin-bottom: 26px; }
.ch-no {
  font-family: var(--mono); font-size: 12px; font-weight: 600;
  letter-spacing: .14em; text-transform: uppercase;
  color: var(--accent); margin-bottom: 10px;
  display: flex; align-items: center; gap: 10px;
}
.ch-no::after {
  content: ""; flex: 0 0 34px; height: 1px;
  background: linear-gradient(90deg, rgba(var(--accent-rgb),.55), transparent);
}
.ch-title {
  font-family: var(--display);
  font-size: clamp(24px, 3.4vw, 33px);
  font-weight: 700; line-height: 1.26;
  letter-spacing: -.018em;
  color: var(--text);
  margin-bottom: 0;
}
.ch-title::after {
  content: ""; display: block;
  width: 46px; height: 3px; border-radius: 2px; margin-top: 16px;
  background: linear-gradient(90deg, var(--accent), var(--teal));
}
.ch-lede {
  color: var(--text-2);
  font-size: 16.5px; line-height: 1.72;
  margin-top: 16px;
}

/* ────────────────────────────── 正文排印 ────────────────────────────── */
h3.sub {
  font-family: var(--display);
  font-size: clamp(18.5px, 2.3vw, 21px);
  font-weight: 600; line-height: 1.4;
  letter-spacing: -.012em;
  color: var(--text);
  margin: 36px 0 13px;
  padding-left: 15px; position: relative;
}
h3.sub::before {
  content: ""; position: absolute; left: 0; top: .34em;
  width: 3px; height: .92em; border-radius: 2px;
  background: var(--teal);
}
h4.minor {
  font-size: 16.5px; font-weight: 600; letter-spacing: -.008em;
  margin: 26px 0 9px; color: var(--text);
}
p { margin-bottom: 16px; color: var(--text); }
p:last-child { margin-bottom: 0; }
strong { font-weight: 600; color: var(--text); }
em { font-style: normal; font-weight: 600; color: var(--accent); }
del { color: var(--text-3); }
a.inline {
  color: var(--accent); text-decoration: none;
  border-bottom: 1px solid rgba(var(--accent-rgb),.30);
  transition: border-color .18s;
}
a.inline:hover { border-bottom-color: var(--accent); }
code.inline {
  font-family: var(--mono); font-size: .88em;
  background: rgba(var(--accent-rgb),.09);
  color: var(--accent-deep);
  padding: 2.5px 6px; border-radius: 6px;
  white-space: nowrap;
}
hr.divider { border: none; border-top: 1px solid var(--line); margin: 40px 0; }

ul.plain, ol.plain { margin: 0 0 16px; padding-left: 22px; }
ul.plain li, ol.plain li { margin-bottom: 9px; padding-left: 3px; line-height: 1.75; }
ul.plain li::marker { color: var(--text-3); }
ol.plain li::marker { color: var(--text-3); font-family: var(--mono); font-size: .92em; }
ul.plain li > ul, ul.plain li > ol, ol.plain li > ul, ol.plain li > ol { margin-top: 8px; }

/* ────────────────────────────── 提示框 ────────────────────────────── */
.callout {
  border-radius: var(--radius-m);
  padding: 18px 22px;
  margin: 24px 0;
  font-size: 15.5px; line-height: 1.75;
  background: rgba(var(--accent-rgb),.06);
  border: 1px solid rgba(var(--accent-rgb),.14);
}
.callout .co-title {
  font-weight: 600; margin-bottom: 7px;
  display: flex; align-items: center; gap: 8px;
  font-size: 15px; letter-spacing: -.005em;
  color: var(--accent);
}
.callout .co-title::before {
  content: ""; width: 3px; height: 1em; border-radius: 2px;
  background: var(--accent); flex: 0 0 auto;
}
.callout p { margin-bottom: 0; }
.callout p + p { margin-top: 9px; }
.callout ul, .callout ol { margin: 8px 0 0 20px; }
.callout.gold, .callout.orange { background: rgba(var(--orange-rgb),.08); border-color: rgba(var(--orange-rgb),.16); }
.callout.gold .co-title, .callout.orange .co-title { color: var(--orange); }
.callout.gold .co-title::before, .callout.orange .co-title::before { background: var(--orange); }
.callout.red { background: rgba(var(--red-rgb),.07); border-color: rgba(var(--red-rgb),.16); }
.callout.red .co-title { color: var(--red); }
.callout.red .co-title::before { background: var(--red); }
.callout.green { background: rgba(var(--green-rgb),.08); border-color: rgba(var(--green-rgb),.16); }
.callout.green .co-title { color: var(--green); }
.callout.green .co-title::before { background: var(--green); }

/* ────────────────────────────── 引用 ────────────────────────────── */
blockquote.quote {
  margin: 24px 0; padding: 20px 24px;
  border-left: 3px solid var(--teal);
  background: linear-gradient(100deg, rgba(var(--teal-rgb),.07), rgba(var(--accent-rgb),.04) 70%, transparent);
  border-radius: 0 var(--radius-m) var(--radius-m) 0;
  color: var(--text);
  font-size: 17px; line-height: 1.72;
}
blockquote.quote p { margin-bottom: 9px; }
blockquote.quote p:last-child { margin-bottom: 0; }

/* ────────────────────────────── 步骤卡 ────────────────────────────── */
.steps { margin: 26px 0; display: grid; gap: 12px; }
.step {
  position: relative;
  background: var(--bg-inset);
  border: 1px solid var(--line);
  border-radius: var(--radius-m);
  padding: 18px 22px 18px 62px;
  transition: background .2s cubic-bezier(.4,0,.2,1);
}
.step:hover { background: var(--bg-inset-2); }
.step .step-n {
  position: absolute; left: 18px; top: 17px;
  width: 28px; height: 28px; border-radius: 50%;
  background: var(--accent); color: #fff;
  font-family: var(--mono); font-size: 13px; font-weight: 600;
  display: flex; align-items: center; justify-content: center;
}
.step h5 {
  font-size: 16px; font-weight: 600; letter-spacing: -.008em;
  margin-bottom: 5px; color: var(--text);
}
.step p { margin-bottom: 0; font-size: 15.5px; color: var(--text-2); line-height: 1.72; }

/* ────────────────────────────── 表格 ────────────────────────────── */
.table-wrap {
  overflow-x: auto; margin: 26px 0;
  border: 1px solid var(--line);
  border-radius: var(--radius-m);
  background: var(--bg-elev);
}
table { width: 100%; border-collapse: collapse; font-size: 15px; }
thead th {
  background: var(--bg-inset);
  color: var(--text-2);
  text-align: left; padding: 13px 18px;
  font-family: var(--mono); font-size: 11.5px; font-weight: 600;
  letter-spacing: .08em; text-transform: uppercase;
  border-bottom: 1px solid var(--line);
  white-space: nowrap;
}
tbody td {
  padding: 14px 18px;
  border-bottom: 1px solid var(--line);
  vertical-align: top; color: var(--text);
  line-height: 1.7;
}
tbody tr:last-child td { border-bottom: none; }

/* ────────────────────────────── 卡片网格 ────────────────────────────── */
.grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin: 26px 0; }
.grid.g2 { grid-template-columns: repeat(2, 1fr); }
.gcard {
  background: var(--bg-elev-2);
  border: 1px solid var(--line);
  border-radius: var(--radius-m);
  padding: 20px;
  box-shadow: var(--shadow-1);
  transition: transform .28s cubic-bezier(.34,1.3,.64,1), box-shadow .28s cubic-bezier(.4,0,.2,1);
}
.gcard:hover { transform: translateY(-2px); box-shadow: var(--shadow-2); }
.gcard .g-name {
  font-family: var(--display); font-size: 16.5px; font-weight: 600;
  letter-spacing: -.01em; margin-bottom: 5px;
  color: var(--text);
  display: flex; align-items: center; gap: 8px;
}
.gcard .g-name::before {
  content: ""; width: 7px; height: 7px; border-radius: 50%;
  background: var(--accent); flex: 0 0 auto;
}
.gcard .g-tag {
  font-family: var(--mono); font-size: 10.5px; font-weight: 500;
  letter-spacing: .1em; text-transform: uppercase;
  color: var(--text-3); margin-bottom: 10px;
}
.gcard p { font-size: 14px; color: var(--text-2); line-height: 1.68; margin: 0; }
.gcard.t2 .g-name::before { background: var(--teal); }
.gcard.t3 .g-name::before { background: var(--green); }
.gcard.t4 .g-name::before { background: var(--indigo); }

/* ────────────────────────────── 代码 ────────────────────────────── */
pre.code {
  background: var(--code-bg);
  color: var(--code-ink);
  border: 1px solid var(--line);
  border-radius: var(--radius-m);
  padding: 18px 20px;
  overflow-x: auto; margin: 24px 0;
  font-family: var(--mono);
  font-size: 13.5px; line-height: 1.68;
  letter-spacing: 0;
}
pre.code code { font-family: inherit; color: inherit; background: none; padding: 0; border: none; }
pre.code .lang-tag {
  display: block;
  font-size: 10.5px; font-weight: 600;
  letter-spacing: .12em; text-transform: uppercase;
  color: var(--text-3); margin-bottom: 12px;
}

/* ────────────────────────────── 图片 ────────────────────────────── */
figure { margin: 28px 0; }
figure img {
  width: 100%; height: auto; display: block;
  border-radius: var(--radius-m);
  border: 1px solid var(--line);
}
figcaption {
  text-align: center; font-size: 13px; color: var(--text-3);
  margin-top: 10px; line-height: 1.6;
}

/* ────────────────────────────── 结语 ────────────────────────────── */
.ending {
  background:
    radial-gradient(ellipse 60% 80% at 100% 0%, rgba(var(--teal-rgb),.14), transparent 68%),
    linear-gradient(160deg, rgba(var(--accent-rgb),.09), var(--bg-elev) 72%);
  border: 1px solid rgba(var(--accent-rgb),.16);
  border-radius: var(--radius-l);
  padding: clamp(30px, 4vw, 44px);
  margin: 0 0 26px;
  box-shadow: var(--shadow-2);
}
.ending h3 {
  font-family: var(--display);
  font-size: clamp(21px, 2.8vw, 26px); font-weight: 700;
  letter-spacing: -.018em; margin-bottom: 16px;
  color: var(--text); padding: 0; border: none;
}
.ending h3::before { display: none; }
.ending ul, .ending ol { margin-left: 22px; }
.ending li { margin-bottom: 10px; }

.colophon {
  margin-top: 34px; padding-top: 22px;
  border-top: 1px solid var(--line);
  text-align: center; color: var(--text-3);
  font-size: 12.5px; line-height: 1.9;
}

/* ────────────────────────────── 交互 ────────────────────────────── */
.progress {
  position: fixed; top: 0; left: 0; height: 2px; width: 0;
  background: var(--accent); z-index: 99;
  transition: width .1s linear;
}
.totop {
  position: fixed; right: 24px; bottom: 26px;
  width: 42px; height: 42px; border-radius: 50%;
  background: var(--bg-elev);
  border: 1px solid var(--line);
  -webkit-backdrop-filter: blur(24px) saturate(180%);
  backdrop-filter: blur(24px) saturate(180%);
  color: var(--text-2);
  display: flex; align-items: center; justify-content: center;
  cursor: pointer; box-shadow: var(--shadow-2);
  opacity: 0; pointer-events: none;
  transition: opacity .24s, transform .24s cubic-bezier(.34,1.3,.64,1);
  font-size: 15px; font-family: var(--mono);
}
.totop.show { opacity: 1; pointer-events: auto; }
.totop:hover { transform: translateY(-2px); }

.pagebreak { break-after: page; page-break-after: always; height: 0; }

/* 滚动淡入（克制的位移，符合系统动效语言） */
.reveal {
  opacity: 0;
  transform: translateY(22px) scale(.995);
  transition: opacity .7s cubic-bezier(.4,0,.2,1), transform .7s cubic-bezier(.34,1.1,.64,1);
}
.reveal.in { opacity: 1; transform: none; }
@media (prefers-reduced-motion: reduce) {
  html { scroll-behavior: auto; }
  .reveal { opacity: 1; transform: none; transition: none; }
}

/* ────────────────────────────── 响应式 ────────────────────────────── */
@media (max-width: 720px) {
  body { font-size: 16.5px; line-height: 1.76; }
  .page { padding: 0 14px 80px; }
  .hero { padding: 60px 20px 40px; }
  .hero h1 { font-size: 29px; }
  .hero .subtitle { font-size: 15.5px; }
  .chapter-card { padding: 26px 20px; border-radius: var(--radius-m); margin-bottom: 18px; }
  .ch-title { font-size: 22px; }
  .grid, .grid.g2 { grid-template-columns: 1fr; }
  .toc { margin: -22px 0 22px; padding: 6px 4px; }
  .toc li a { padding: 12px 16px; font-size: 15px; }
  h3.sub { font-size: 18px; margin-top: 30px; }
  blockquote.quote { padding: 16px 18px; font-size: 16px; }
  .ending { padding: 26px 20px; border-radius: var(--radius-m); }
  .hero-stat { gap: 18px; font-size: 12px; }
}

/* ────────────────────────────── 打印 / 导出 PDF ────────────────────────────── */
@media print {
  @page { size: A4; margin: 16mm 14mm 15mm; }
  body { background: #fff !important; color: #000 !important; font-size: 10.8pt; line-height: 1.7; }
  .page { max-width: none; padding: 0; }
  .hero {
    background: #fff !important; border-bottom: 1.5pt solid #000;
    padding: 0 0 12pt; margin-bottom: 14pt;
  }
  .hero .kicker, .hero-meta span {
    background: none !important; border-color: #bbb !important;
    color: #333 !important; box-shadow: none !important;
    -webkit-backdrop-filter: none !important; backdrop-filter: none !important;
  }
  .hero h1 { font-size: 19pt; letter-spacing: 0; }
  .hero .subtitle { font-size: 10.5pt; color: #444 !important; }
  .hero-quote { border-left-color: #666 !important; background: none !important; }
  .hero-stat { color: #555 !important; border-top-color: #ddd !important; }
  .toc, .progress, .totop { display: none !important; }
  .chapter-card, .ending {
    background: #fff !important; border: none !important; box-shadow: none !important;
    padding: 0 !important; margin: 0 0 16pt !important;
  }
  .ch-no { color: #666 !important; font-size: 9pt; }
  .ch-no::after { background: #ccc !important; }
  .ch-title { font-size: 15pt; break-after: avoid; page-break-after: avoid; }
  .ch-title::after { display: none; }
  h3.sub { font-size: 12pt; margin: 13pt 0 6pt; break-after: avoid; page-break-after: avoid; }
  h3.sub::before { background: #666 !important; }
  .callout, .step, .gcard, figure, .table-wrap, blockquote.quote {
    break-inside: avoid; page-break-inside: avoid; box-shadow: none !important;
    background: #fafafa !important; border-color: #ddd !important;
  }
  .table-wrap { border: 1px solid #ccc; }
  thead { display: table-header-group; }
  thead th { background: #f0f0f0 !important; color: #000 !important; }
  pre.code { background: #f5f5f5 !important; color: #111 !important; border-color: #ddd; }
  .grid { grid-template-columns: repeat(2, 1fr); gap: 8pt; }
  a.inline { color: #000; border-bottom: none; }
  a.inline::after { content: " (" attr(href) ")"; font-size: 8.5pt; color: #666; }
  .reveal { opacity: 1 !important; transform: none !important; }
  .pagebreak { break-after: page; page-break-after: always; }
}
"""

JS_PROGRESS = """
(function(){
  var bar=document.getElementById('progress'), top=document.getElementById('totop');
  function upd(){
    var h=document.documentElement, max=h.scrollHeight-h.clientHeight;
    var y=h.scrollTop||document.body.scrollTop;
    var pct=max>0?y/max*100:0;
    if(bar) bar.style.width=pct+'%';
    if(top) top.classList.toggle('show', y>600);
  }
  window.addEventListener('scroll', upd, {passive:true});
  window.addEventListener('resize', upd);
  upd();
  if(top) top.addEventListener('click', function(){ window.scrollTo({top:0, behavior:'smooth'}); });
  var els=document.querySelectorAll('.reveal');
  if(!('IntersectionObserver' in window)){ els.forEach(function(e){e.classList.add('in');}); return; }
  var vh=window.innerHeight||document.documentElement.clientHeight;
  var io=new IntersectionObserver(function(entries){
    entries.forEach(function(en){
      if(en.isIntersecting){ en.target.classList.add('in'); io.unobserve(en.target); }
    });
  },{rootMargin:'0px 0px -6% 0px', threshold:.04});
  els.forEach(function(e,i){
    var r=e.getBoundingClientRect();
    if(r.top < vh*0.96){ e.classList.add('in'); e.style.transition='none'; }
    else { e.style.transitionDelay=((i%4)*40)+'ms'; io.observe(e); }
  });
})();
"""


def _fonts() -> str:
    """字体栈：SF Pro 优先（macOS / iOS 原生），中文回落苹方；数字与标签走 SF Mono。"""
    return """
    --display: -apple-system, BlinkMacSystemFont, "SF Pro Display", "Helvetica Neue",
               "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif;
    --sans: -apple-system, BlinkMacSystemFont, "SF Pro Text", "Helvetica Neue",
            "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif;
    --mono: ui-monospace, SFMono-Regular, "SF Mono", Menlo, "JetBrains Mono", Consolas, monospace;
    """


def _block(vars_dict) -> str:
    return "\n".join("    %s: %s;" % (k, v) for k, v in vars_dict.items())


def build_css(theme: str = DEFAULT_THEME, scheme: str = "auto") -> str:
    """拼装 :root 变量 + 基础样式。

    scheme: auto  跟随系统（浅色主题自动获得深色变体）
            light 强制浅色
            dark  强制深色
    """
    t = THEMES.get(theme, THEMES[DEFAULT_THEME])
    light = t["vars"]
    dark = t.get("dark_vars")

    if scheme == "dark" and dark:
        root = ":root {\n%s%s\n}\n" % (_fonts(), _block(dark))
    else:
        root = ":root {\n%s%s\n}\n" % (_fonts(), _block(light))
        if scheme == "auto" and dark:
            root += "@media (prefers-color-scheme: dark) {\n:root {\n%s\n}\n}\n" % _block(dark)

    return root + BASE_CSS


def list_themes() -> list:
    return [(k, v["label"], v["desc"]) for k, v in THEMES.items()]
