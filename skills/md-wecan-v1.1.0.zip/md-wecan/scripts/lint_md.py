#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
lint_md.py —— Markdown 排版规范检查器。

检查项：
  1. frontmatter 是否闭合（--- 成对，且各自独占一行）
  2. 标题层级是否跳级（h1 → h3）
  3. h1 是否唯一
  4. 章节编号是否重复 / 断号（## 01 / ## 02 …）
  5. 围栏代码块是否闭合
  6. 表格列数是否一致
  7. callout 标记是否为已知类型
  8. 图片路径是否存在
  9. 待补的 frontmatter 空字段（subtitle / tags / quote）

用法：
  python3 lint_md.py doc.md            # 输出问题清单
  python3 lint_md.py doc.md --fix      # 自动修复可修复项（写回原文件，建议先备份）
"""
import os
import re
import sys
import argparse

KNOWN_ALERTS = {
    "NOTE", "INFO", "ABSTRACT", "SUMMARY", "TIP", "SUCCESS", "CHECK", "DONE",
    "IMPORTANT", "QUESTION", "KEY", "IDEA", "WARNING", "CAUTION", "DANGER",
    "BUG", "FAIL",
}
FM_FIELDS = ("title", "subtitle", "kicker", "author", "date", "tags", "quote", "theme")


def parse(text: str):
    lines = text.replace("\r\n", "\n").split("\n")
    fm, body_start = None, 0
    if lines and lines[0].strip() == "---":
        for i in range(1, len(lines)):
            if lines[i].strip() in ("---", "..."):
                fm, body_start = lines[1:i], i + 1
                break
    return fm, lines[body_start:]


def lint(path: str):
    issues = []
    text = open(path, encoding="utf-8").read()
    fm_lines, body = parse(text)

    # 1. frontmatter
    if text.lstrip().startswith("---") and fm_lines is None:
        issues.append(("error", 1, "frontmatter 未闭合：首行 --- 没有对应的闭合 ---（必须独占一行）"))
    if fm_lines is not None:
        keys = [m.group(1) for ln in fm_lines
                if (m := re.match(r"^([A-Za-z_][\w-]*)\s*:", ln))]
        dup = {k for k in keys if keys.count(k) > 1}
        if dup:
            issues.append(("error", 0, "frontmatter 字段重复：%s" % ", ".join(sorted(dup))))
        empty = [k for k in ("subtitle", "tags", "quote") if k in keys]
        for k in empty:
            val = ""
            for ln in fm_lines:
                m = re.match(r"^%s\s*:\s*(.*)$" % k, ln)
                if m:
                    val = m.group(1).strip()
                    break
            if val in ("", "\"\"", "[]", "''"):
                issues.append(("warn", 0, "frontmatter 字段待补全：%s" % k))

    # 2-4. 标题
    h1 = []
    last_level = 0
    chapter_nums = []
    in_fence = False
    for i, raw in enumerate(body, 1):
        s = raw.strip()
        if s.startswith("```"):
            in_fence = not in_fence
            continue
        if in_fence:
            continue
        m = re.match(r"^(#{1,6})\s+(.*)$", s)
        if m:
            level, content = len(m.group(1)), m.group(2).strip()
            if level == 1:
                h1.append((i, content))
            if last_level and level > last_level + 1:
                issues.append(("warn", i, "标题跳级：h%d 直接出现在 h%d 之后（%s）"
                               % (level, last_level, content[:24])))
            last_level = level
            if level == 2:
                cm = re.match(r"^(\d{1,2})[\s、.]\s*(.+)$", content)
                if cm:
                    chapter_nums.append((int(cm.group(1)), cm.group(1), content))
                else:
                    issues.append(("info", i, "章节无编号（将自动按顺序编号）：%s" % content[:24]))
    if len(h1) > 1:
        issues.append(("error", h1[0][0], "出现 %d 个一级标题（只应保留一个，其余请降级为 ##/###）"
                       % len(h1)))

    nums = [n for n, _, _ in chapter_nums]
    if len(nums) != len(set(nums)):
        issues.append(("error", 0, "章节编号重复：%s" %
                       [orig for n, orig, _ in chapter_nums if nums.count(n) > 1]))
    if nums and sorted(nums) != list(range(nums[0], nums[0] + len(nums))):
        issues.append(("warn", 0, "章节编号可能断号：%s" % nums))

    # 5-7. 围栏 / 表格 / callout
    in_fence, fence_start = False, 0
    for i, raw in enumerate(body, 1):
        s = raw.strip()
        if s.startswith("```"):
            if not in_fence:
                in_fence, fence_start = True, i
            else:
                in_fence = False
            continue
        if in_fence:
            continue
        m = re.match(r"^>\s*\[!(\w+)\]", s)
        if m and m.group(1).upper() not in KNOWN_ALERTS:
            issues.append(("warn", i, "未知提示框类型 [!%s]，将按蓝色渲染" % m.group(1)))
        if s.startswith("|") and i < len(body):
            nxt = body[i + 1].strip() if i < len(body) else ""
            if re.match(r"^\|[\s:|-]+\|?\s*$", nxt):
                cols = len(re.split(r"(?<!\\)\|", s.strip().strip("|")))
                sep_cols = len(re.split(r"(?<!\\)\|", nxt.strip().strip("|")))
                if cols != sep_cols:
                    issues.append(("error", i, "表格分隔行列数（%d）与表头（%d）不一致" % (sep_cols, cols)))
    if in_fence:
        issues.append(("error", fence_start, "代码围栏未闭合（第 %d 行的 ``` 没有配对）" % fence_start))

    # 8. 图片
    base = os.path.dirname(os.path.abspath(path))
    for i, raw in enumerate(body, 1):
        for m in re.finditer(r"!\[[^\]]*\]\(([^)\s]+)\)", raw):
            src = m.group(1)
            if src.startswith(("http://", "https://", "data:")):
                continue
            if not os.path.exists(os.path.join(base, src)):
                issues.append(("warn", i, "图片文件不存在：%s" % src))

    return issues


def fix(path: str) -> int:
    """自动修复：标题跳级降级、frontmatter 待补字段补占位。返回修复数。"""
    text = open(path, encoding="utf-8").read()
    fixed = 0
    lines = text.replace("\r\n", "\n").split("\n")
    out, last_level, in_fence = [], 0, False
    for raw in lines:
        s = raw.strip()
        if s.startswith("```"):
            in_fence = not in_fence
            out.append(raw)
            continue
        m = re.match(r"^(#{1,6})\s+(.*)$", s) if not in_fence else None
        if m:
            level = len(m.group(1))
            if last_level and level > last_level + 1:
                level = last_level + 1
                raw = "#" * level + " " + m.group(2)
                fixed += 1
            last_level = level
        out.append(raw)
    new = "\n".join(out)
    # 补齐空字符串字段
    for k in ("subtitle", "kicker", "quote"):
        new, n = re.subn(r"^%s:\s*$" % k, '%s: ""' % k, new, flags=re.M)
        fixed += n
    if fixed and new != text:
        with open(path, "w", encoding="utf-8", newline="\n") as f:
            f.write(new)
    return fixed


def main():
    ap = argparse.ArgumentParser(description="Markdown 排版规范检查")
    ap.add_argument("input")
    ap.add_argument("--fix", action="store_true", help="自动修复可修复项并写回")
    args = ap.parse_args()
    path = os.path.abspath(args.input)
    if not os.path.exists(path):
        print("找不到文件：%s" % path)
        sys.exit(1)

    if args.fix:
        n = fix(path)
        print("已自动修复 %d 处" % n)

    issues = lint(path)
    if not issues:
        print("ALL PASS ✓ 未发现规范问题")
        return
    icon = {"error": "✗", "warn": "⚠", "info": "·"}
    for kind, line, msg in issues:
        loc = ("第 %d 行：" % line) if line else ""
        print("[%s] %s%s" % (icon[kind], loc, msg))
    n_err = sum(1 for k, _, _ in issues if k == "error")
    print("---")
    print("共 %d 项（错误 %d，提醒 %d，提示 %d）"
          % (len(issues), n_err,
             sum(1 for k, _, _ in issues if k == "warn"),
             sum(1 for k, _, _ in issues if k == "info")))
    sys.exit(1 if n_err else 0)


if __name__ == "__main__":
    main()
