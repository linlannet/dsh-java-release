#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ingest.py —— 来源预处理：TXT / PDF → 结构规范化的 Markdown 草稿。

做的事：
  1. 抽取纯文本（PDF 走 pypdf，缺失时给出安装提示）；
  2. 修复断行：把被硬换行切碎的段落重新合并成自然段；
  3. 识别章节：`第X章` / `一、` / `01 标题` / `1. 标题` / `【标题】` 等常见形态，
     统一改写为 `## NN 标题`；
  4. 生成 frontmatter 骨架（title 自动填充，其余留待作者补全）。

用法：
  python3 ingest.py input.pdf                 # 输出 input.md（同目录）
  python3 ingest.py input.txt -o out/x.md
  python3 ingest.py input.txt --stdin-only    # 只打印，不写文件
"""
import os
import re
import sys
import argparse

CN_NUM = "一二三四五六七八九十百零"
HAN = r"[\u4e00-\u9fff]"
HAN_C = "\u4e00-\u9fff"  # 用于字符类内部插值（不带方括号）

# 章节标题的常见形态（行首匹配，行要短）
CHAPTER_PATTERNS = [
    re.compile(r"^第\s*[%s\d]+\s*[章节讲部回篇]\s*[、.．:：]?\s*\S.*$" % CN_NUM),
    re.compile(r"^[一二三四五六七八九十]+\s*[、.．]\s*\S.*$"),
    re.compile(r"^\d{1,2}\s*[、.．]\s*%s+.*$" % HAN),      # 1、中文标题
    re.compile(r"^【(.{1,30})】\s*$"),
    re.compile(r"^\d{1,2}\s+%s{2,}.*$" % HAN),             # 01 中文标题
]
NOISE_PATTERNS = [
    re.compile(r"^第\s*\d+\s*页"), re.compile(r"^\d+\s*/\s*\d+$"),
    re.compile(r"^[-—_=·•\s]+$"),
]


def looks_like_chapter(line: str) -> bool:
    s = line.strip()
    if not s or len(s) > 40:
        return False
    if any(p.match(s) for p in NOISE_PATTERNS):
        return False
    return any(p.match(s) for p in CHAPTER_PATTERNS)


def chapter_title(line: str):
    """提取标题文本并识别已有编号。"""
    s = line.strip().strip("【】").strip()
    s = re.sub(r"^第\s*[%s\d]+\s*[章节讲部回篇]\s*[、.．:：]?\s*" % CN_NUM, "", s)
    m = re.match(r"^([一二三四五六七八九十]+|\d{1,2})\s*[、.．\s]\s*(.+)$", s)
    if m:
        return m.group(2).strip(), s
    return s, s


def cn_to_int(cn: str) -> int:
    table = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5,
             "六": 6, "七": 7, "八": 8, "九": 9, "十": 10}
    if cn in table:
        return table[cn]
    if cn == "十":
        return 10
    m = re.match(r"^十([一二三四五六七八九])$", cn)
    if m:
        return 10 + table[m.group(1)]
    m = re.match(r"^([一二三四五六七八九])十$", cn)
    if m:
        return table[m.group(1)] * 10
    m = re.match(r"^([一二三四五六七八九])十([一二三四五六七八九])$", cn)
    if m:
        return table[m.group(1)] * 10 + table[m.group(2)]
    try:
        return int(cn)
    except ValueError:
        return 0


def extract_text(path: str) -> str:
    import unicodedata
    ext = os.path.splitext(path)[1].lower()
    if ext == ".txt":
        raw = open(path, encoding="utf-8", errors="replace").read()
    elif ext == ".pdf":
        try:
            from pypdf import PdfReader
        except ImportError:
            print("缺少 pypdf，请先安装：pip install pypdf", file=sys.stderr)
            sys.exit(2)
        reader = PdfReader(path)
        raw = "\n".join((p.extract_text() or "") for p in reader.pages)
    elif ext == ".md":
        raw = open(path, encoding="utf-8", errors="replace").read()
    else:
        print("不支持的来源格式：%s（支持 .txt / .pdf / .md）" % ext, file=sys.stderr)
        sys.exit(2)
    # NFKC 归一化：把 PDF 常见的康熙部首/兼容字符（⽤⼤⻄）还原为常规汉字
    text = unicodedata.normalize("NFKC", raw)
    # NFKC 覆盖不到的部首补充映射
    extra = {"⻄": "西", "⻘": "青", "⻓": "长", "⻔": "门", "⻢": "马", "⻛": "风",
             "⻜": "飞", "⻝": "食", "⻥": "鱼", "⻚": "页", "⻤": "鬼", "⻣": "骨",
             "⻤": "鬼", "⻯": "竜", "⻰": "龙", "⻳": "龟", "⻆": "角", "⻉": "贝",
             "⻋": "车", "⻍": "辶", "⻎": "辶", "⻏": "阝", "⻒": "阝", "⻛": "风"}
    for k, v in extra.items():
        text = text.replace(k, v)
    # NFKC 会把全角标点转成半角，这里按中文上下文还原
    punct = {",": "，", ";": "；", ":": "：", "?": "？", "!": "！"}
    han = "\u4e00-\u9fff"
    text = re.sub("(?<=[%s])[,;:?!](?=[%s\\s]|$)" % (han, han),
                  lambda m: punct[m.group(0)], text)
    text = re.sub("(?<=%s)\\((?=[^)]{1,20}\\))" % han, "（", text)
    text = re.sub("\\)(?=[%s\\s]|$)" % han, "）", text)
    return text


def merge_paragraphs(text: str) -> list:
    """把硬换行合并为自然段：非空行聚成块，块内拼接。"""
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    blocks, buf = [], []
    for raw in text.split("\n"):
        s = raw.strip()
        if not s:
            if buf:
                blocks.append(" ".join(buf))
                buf = []
            continue
        buf.append(s)
    if buf:
        blocks.append(" ".join(buf))
    return blocks


def is_sentence_end(s: str) -> bool:
    return bool(s) and s[-1] in "。！？…；：.!?;:\"」』）)"


def reflow(block: str) -> str:
    """中文文本去掉块内多余空格（保留英文单词间空格）。"""
    block = re.sub(r"(?<=%s) +(?=%s)" % (HAN, HAN), "", block)
    block = re.sub(r"(%s) +([，。！？；：、）」』])" % HAN, r"\1\2", block)
    block = re.sub(r"([（「『]) +(%s)" % HAN, r"\1\2", block)
    return block


def structure(text: str) -> list:
    """→ [(kind, payload)]，kind ∈ chapter / para。

    按中文句末标点切句，短句若命中章节形态则单独成章，
    其余句子依次并入段落。这样能处理整篇无空行的 PDF 文本。
    """
    out = []
    buf = []

    def flush():
        if buf:
            out.append(("para", reflow("".join(buf))))
            buf.clear()

    for block in merge_paragraphs(text):
        for sent in re.split(r"(?<=[。！？…；：])", block):
            s = sent.strip()
            if not s:
                continue
            # 句内二次切分：处理「……正文 04 章节标题？……」这种标题嵌在长句里的情况
            for piece in re.split(r"(?=(?:0[1-9]|1[0-9]|2[0-5])\s+[\u4e00-\u9fff]{2,})", s):
                p = piece.strip()
                if not p:
                    continue
                if len(p) <= 40 and looks_like_chapter(p):
                    flush()
                    title, _ = chapter_title(p)
                    out.append(("chapter", title))
                else:
                    buf.append(p)
        flush()
    return out


def build_md(text: str, source_name: str) -> str:
    parts = structure(text)
    lines = ["---", "title: %s" % re.sub(r"\.(txt|pdf|md)$", "", source_name),
             "subtitle: \"\"", "kicker: \"\"", "author: \"\"", "date: \"\"",
             "tags: []", "quote: \"\"", "theme: azure", "---", ""]
    idx = 0
    intro = []
    for kind, payload in parts:
        if kind == "chapter":
            break
        intro.append(payload)
    if intro:
        lines += intro
        lines.append("")
    for kind, payload in parts:
        if kind == "chapter":
            idx += 1
            lines += ["", "## %02d %s" % (idx, payload), ""]
        else:
            lines += [payload, ""]
    if idx == 0 and parts:
        # 没识别出章节：全部作为正文段落
        lines = lines[:]  # 保持 intro + 段落
    return "\n".join(lines).rstrip() + "\n"


def main():
    ap = argparse.ArgumentParser(description="TXT/PDF → 规范化 Markdown 草稿")
    ap.add_argument("input")
    ap.add_argument("-o", "--output")
    ap.add_argument("--stdin-only", action="store_true")
    args = ap.parse_args()

    path = os.path.abspath(args.input)
    if not os.path.exists(path):
        print("找不到文件：%s" % path)
        sys.exit(1)
    md = build_md(extract_text(path), os.path.basename(path))
    if args.stdin_only:
        print(md)
        return
    dst = args.output or os.path.splitext(path)[0] + ".md"
    os.makedirs(os.path.dirname(os.path.abspath(dst)), exist_ok=True)
    with open(dst, "w", encoding="utf-8", newline="\n") as f:
        f.write(md)
    print("OK", dst)


if __name__ == "__main__":
    main()
