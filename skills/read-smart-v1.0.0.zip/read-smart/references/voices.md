# 可选语音列表（Microsoft Edge TTS）

通过 `--voice` 参数指定。常用中文与英文声线如下，未列出的语言可参考
Microsoft 官方「Neural voice names and locales」文档。

## 中文（简体）zh-CN
| 语音名 | 声线 | 说明 |
| --- | --- | --- |
| `zh-CN-XiaoxiaoNeural` | 女 | 默认，自然流畅 |
| `zh-CN-YunxiNeural` | 男 | 年轻男声 |
| `zh-CN-YunyangNeural` | 男 | 新闻播音腔 |
| `zh-CN-XiaoyiNeural` | 女 | 温暖女声 |
| `zh-CN-YunjianNeural` | 男 | 沉稳男声 |
| `zh-CN-YunxiaNeural` | 女 | 清新女声 |
| `zh-CN-YunyeNeural` | 男 | 磁性男声 |

## 英文 en-US
| 语音名 | 声线 | 说明 |
| --- | --- | --- |
| `en-US-AriaNeural` | 女 | 默认英文女声 |
| `en-US-GuyNeural` | 男 | 英文男声 |
| `en-US-JennyNeural` | 女 | 英文女声 |

## 其他常用
- 日语：`ja-JP-NanamiNeural`
- 韩语：`ko-KR-SunHiNeural`
- 法语：`fr-FR-DeniseNeural`

> 提示：若只需中文，默认 `zh-CN-XiaoxiaoNeural` 即可；英文网页可加
> `--voice en-US-AriaNeural` 或 `--lang en`。
