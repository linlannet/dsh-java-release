#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
read-smart — 把网页、本地 HTML、Markdown 或纯文本的正文「读懂 → 重新组织 → 读声音」，
生成 mp3 音频，并可同步生成字幕（SRT / LRC）与带字幕高亮同步的 HTML 播放器。

用法：
  python3 read_smart.py <网址或本地文件路径> [选项]
  python3 read_smart.py --text "要朗读的文本..." [选项]

常见：
  python3 read_smart.py https://example.com/article
  python3 read_smart.py ./page.html --voice zh-CN-YunyangNeural
  python3 read_smart.py ./note.md
  python3 read_smart.py ./article.txt
  python3 read_smart.py --text-file reframed.txt --config my_config.json

配置（优先级：命令行 > 配置文件 > 内置默认）：
  支持 --config 指定 JSON 配置文件，或在技能目录 / ~/.config/read-smart/ 放 config.json。
  可配置项：voice / lang / rate / volume / max_chars / output_template / subtitle / sub_format
"""

import argparse
import asyncio
import base64
import json
import re
import shutil
import subprocess
import sys
import urllib.parse
from datetime import datetime
from pathlib import Path

DEFAULT_VOICES = {
    "zh": "zh-CN-XiaoxiaoNeural",   # 中文·女声（默认）
    "en": "en-US-AriaNeural",       # 英文·女声
}

USER_AGENT = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
             "(KHTML, like Gecko) Chrome/120.0 Safari/537.36")

SKILL_DIR = Path(__file__).resolve().parent.parent
CONFIG_CANDIDATES = [
    SKILL_DIR / "config.json",
    Path.home() / ".config" / "read-smart" / "config.json",
]

# 内置默认（可被配置文件 / 命令行覆盖）
BUILTIN_DEFAULTS = {
    "voice": None,
    "lang": "zh",
    "rate": None,        # 语速，如 +10% / -5% / slow / fast
    "volume": None,      # 音量，如 +0% / -10% / loud
    "max_chars": 2000,
    "output_template": "{title}",   # 命名模板：{title}{voice}{date}{lang}
    "subtitle": True,    # 是否生成同步字幕
    "sub_format": "srt", # srt / lrc / both
}


# --------------------------------------------------------------------------- #
# 依赖
# --------------------------------------------------------------------------- #
def _pip_install(pkgs, extra=None):
    cmd = [sys.executable, "-m", "pip", "install", "--quiet"]
    if extra:
        cmd += extra
    cmd += list(pkgs)
    subprocess.check_call(cmd)


def ensure_deps(allow_install=True):
    specs = [("edge_tts", "edge-tts"), ("requests", "requests"), ("bs4", "beautifulsoup4")]
    missing = []
    for mod, pkg in specs:
        try:
            __import__(mod)
        except ImportError:
            missing.append(pkg)
    if not missing:
        return True
    if not allow_install:
        print(f"❌ 缺少依赖：{', '.join(missing)}。请先安装后再运行（或去掉 --no-install）。", file=sys.stderr)
        return False
    print(f"⏬ 正在安装依赖：{', '.join(missing)} …")
    try:
        _pip_install(missing)
    except subprocess.CalledProcessError:
        print("⚠️ 常规安装失败，尝试 --break-system-packages …")
        try:
            _pip_install(missing, ["--break-system-packages"])
        except subprocess.CalledProcessError as e:
            print(f"❌ 依赖安装失败：{e}", file=sys.stderr)
            return False
    for mod, pkg in specs:
        try:
            __import__(mod)
        except ImportError:
            print(f"❌ 安装后仍缺少 {pkg}。", file=sys.stderr)
            return False
    return True


# --------------------------------------------------------------------------- #
# 配置
# --------------------------------------------------------------------------- #
def load_config(cli_path):
    candidates = []
    if cli_path:
        candidates.append(Path(cli_path))
    candidates.extend(CONFIG_CANDIDATES)
    for p in candidates:
        if p and Path(p).exists():
            try:
                data = json.loads(Path(p).read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    print(f"⚙️ 已加载配置：{p}")
                    return data
            except Exception as e:
                print(f"⚠️ 配置读取失败 {p}：{e}", file=sys.stderr)
    return {}


# --------------------------------------------------------------------------- #
# 正文提取
# --------------------------------------------------------------------------- #
def extract_main_text(soup, source=""):
    for tag in soup(["script", "style", "noscript", "header", "footer",
                     "nav", "aside", "form", "svg", "iframe", "template"]):
        tag.decompose()
    title = soup.title.get_text(strip=True) if soup.title else ""
    container = soup.find("article") or soup.find("main") or soup.body or soup
    blocks = []
    if title:
        # 标题若无句末标点，补一个句号，避免被 edge-tts 并入下一句
        title_block = title if title[-1:] in "。！？.!?" else title + "。"
        blocks.append(title_block)
    for elem in container.find_all(["h1", "h2", "h3", "h4", "h5", "p", "li", "blockquote"]):
        t = elem.get_text(separator=" ", strip=True)
        if t and t != title:   # 跳过与标题重复的 h1，避免字幕/朗读重复
            blocks.append(t)
    text = "\n".join(blocks)
    text = re.sub(r"[ \t]{2,}", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = text.strip()
    return title, text


def fetch_url_text(url):
    import requests
    from bs4 import BeautifulSoup
    print(f"🌐 正在抓取：{url}")
    r = requests.get(url, headers={"User-Agent": USER_AGENT}, timeout=30)
    r.raise_for_status()
    r.encoding = r.apparent_encoding or r.encoding or "utf-8"
    soup = BeautifulSoup(r.text, "html.parser")
    return extract_main_text(soup, url)


def _decode_bytes(raw):
    """探测解码正文：优先 utf-8，失败回退 gb18030（兼容 GBK 中文网页）。"""
    for enc in ("utf-8", "gb18030"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="ignore")


def _ensure_quoted(url):
    """对 URL 的 path/query 做百分号编码（中文等），避免 requests 因非 ASCII 报错。
    先 unquote 再 quote，保证对已编码片段幂等（不双重编码）。"""
    parts = urllib.parse.urlsplit(url)
    path = urllib.parse.quote(urllib.parse.unquote(parts.path), safe="/")
    query = urllib.parse.quote(urllib.parse.unquote(parts.query), safe="=&")
    return urllib.parse.urlunsplit((parts.scheme, parts.netloc, path, query, parts.fragment))


def is_workbuddy_share(url):
    """判断是否为 WorkBuddy 资料库分享/空间页（运行时渲染，需提取真实正文）。"""
    u = url.lower()
    return ("workbuddy.link/p/" in u) or ("workbuddy.cn/space" in u)


def fetch_workbuddy_text(url):
    """处理资料库分享页：从发布壳定位真实静态正文资源并提取。"""
    import requests
    from bs4 import BeautifulSoup
    print(f"🌐 识别为资料库分享页，提取真实正文：{url}")
    r = requests.get(url, headers={"User-Agent": USER_AGENT}, timeout=30)
    r.raise_for_status()
    shell = r.text

    real_url = None
    # 方式一：页面里直接出现静态资源真实地址（协议可选，中文文件名自动编码）
    m = re.search(r'([^\s"\'<>]*workbuddy-space-static\.codebuddy\.work[^\s"\'<>]*\.html)',
                  shell, re.I)
    if m:
        u = m.group(1)
        if u.startswith("//"):
            u = "https:" + u
        elif not u.lower().startswith("http"):
            u = "https://" + u
        real_url = _ensure_quoted(u)
    # 方式二：从 __PUBLISH_BOOTSTRAP__ 解析（资料库发布页标准结构）
    if not real_url:
        boot = re.search(r'__PUBLISH_BOOTSTRAP__\s*=\s*', shell)
        if boot:
            start = shell.find("{", boot.end())
            if start != -1:
                depth, end = 0, -1
                for i in range(start, len(shell)):
                    if shell[i] == "{":
                        depth += 1
                    elif shell[i] == "}":
                        depth -= 1
                        if depth == 0:
                            end = i
                            break
                if end != -1:
                    try:
                        data = json.loads(shell[start:end + 1])
                        art = data.get("artifact", {})
                        base = art.get("url") or data.get("assetBase") or data.get("base") or ""
                        html_paths = [a.get("path") for a in art.get("artifacts", [])
                                      if str(a.get("path", "")).endswith(".html")]
                        fname = html_paths[0] if html_paths else (
                            data.get("title") or data.get("name") or data.get("fileName") or "")
                        if base and fname:
                            real_url = _ensure_quoted(
                                base.rstrip("/") + "/" + urllib.parse.quote(str(fname)))
                    except Exception:
                        pass
    if not real_url:
        raise ValueError("未能从资料库分享页定位真实正文资源；请改用复制正文或导出文件方式。")

    print(f"🔗 真实正文资源：{real_url}")
    rr = requests.get(real_url, headers={"User-Agent": USER_AGENT}, timeout=30)
    rr.raise_for_status()
    text = _decode_bytes(rr.content)
    soup = BeautifulSoup(text, "html.parser")
    return extract_main_text(soup, url)


PLAIN_TEXT_EXTS = {".md", ".markdown", ".txt", ".text", ".rst", ""}


def _extract_plain_text(raw, source=""):
    """从 Markdown / 纯文本中提取标题与正文，去除常见 Markdown 语法标记。"""
    title = ""
    for line in raw.splitlines():
        s = line.strip()
        if not s:
            continue
        m = re.match(r"^#{1,6}\s+(.+)$", s)
        if m:
            title = m.group(1).strip()
        else:
            title = re.sub(r"^[>\-*+\d.\s]+", "", s).strip()
        break

    text = raw
    text = re.sub(r"```.*?```", "", text, flags=re.S)          # 代码块
    text = re.sub(r"`([^`]*)`", r"\1", text)                   # 行内代码
    text = re.sub(r"!\[([^\]]*)\]\([^)]*\)", r"\1", text)      # 图片
    text = re.sub(r"\[([^\]]*)\]\([^)]*\)", r"\1", text)       # 链接
    text = re.sub(r"^#{1,6}\s+", "", text, flags=re.M)         # 标题符号
    text = re.sub(r"[*_]{1,3}([^*_\n]+)[*_]{1,3}", r"\1", text)  # 加粗/斜体
    text = re.sub(r"^\s*>\s?", "", text, flags=re.M)           # 引用
    text = re.sub(r"^\s*[-*+]\s+", "", text, flags=re.M)       # 无序列表
    text = re.sub(r"^\s*\d+\.\s+", "", text, flags=re.M)       # 有序列表
    text = re.sub(r"^\s*([-*_])\1{2,}\s*$", "", text, flags=re.M)  # 分隔线
    text = re.sub(r"[ \t]{2,}", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text).strip()
    if title and text.startswith(title):
        text = text[len(title):].lstrip("：: \n")
    return title, text


def read_file_text(path):
    print(f"📄 正在读取本地文件：{path}")
    raw = Path(path).read_text(encoding="utf-8", errors="ignore")
    ext = Path(path).suffix.lower()
    if ext in PLAIN_TEXT_EXTS:
        return _extract_plain_text(raw, path)
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(raw, "html.parser")
    return extract_main_text(soup, path)


def split_text(text, max_chars):
    sentences = re.split(r"(?<=[。.!?！？；;\n])", text)
    chunks, cur = [], ""
    for s in sentences:
        s = s.strip()
        if not s:
            continue
        if len(cur) + len(s) <= max_chars:
            cur += s
        else:
            if cur:
                chunks.append(cur)
            while len(s) > max_chars:
                chunks.append(s[:max_chars])
                s = s[max_chars:]
            cur = s
    if cur:
        chunks.append(cur)
    return chunks


# --------------------------------------------------------------------------- #
# 合成 + 字幕
# --------------------------------------------------------------------------- #
def mp3_duration_ms(path):
    try:
        out = subprocess.check_output(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=1:nokey=1", str(path)])
        return float(out.strip()) * 1000.0
    except Exception:
        return 0.0


async def _stream_chunk(text, voice, rate, volume):
    """用 stream 模式合成一段文本，返回 (mp3_bytes, [(offset100ns, dur100ns, text), ...])。"""
    import edge_tts
    kw = {}
    if rate:
        kw["rate"] = rate
    if volume:
        kw["volume"] = volume
    communicate = edge_tts.Communicate(text, voice, **kw)
    buf = b""
    subs = []
    async for ev in communicate.stream():
        if ev.get("type") == "audio":
            buf += ev.get("data", b"")
        elif ev.get("type") == "SentenceBoundary":
            subs.append((ev.get("offset", 0), ev.get("duration", 0), ev.get("text", "")))
    return buf, subs


async def synthesize(text, voice, rate, volume, max_chars, out_mp3, tmp_dir,
                     make_subtitle, sub_format, embed="auto"):
    """合成音频；可选生成字幕。返回字幕列表 [(start_ms, end_ms, text)]。"""
    if not text:
        raise ValueError("没有可朗读的正文文本。")
    chunks = split_text(text, max_chars)
    print(f"🔊 语音 [{voice}]" + (f" 语速[{rate}]" if rate else "") +
          (f" 音量[{volume}]" if volume else "") + f" · 共 {len(chunks)} 段合成 …")

    parts = []
    subs = []          # 全局毫秒时间戳
    base_ms = 0.0
    for i, ch in enumerate(chunks):
        part = tmp_dir / f"part_{i}.mp3"
        buf, chunk_subs = await _stream_chunk(ch, voice, rate, volume)
        part.write_bytes(buf)
        dur_ms = mp3_duration_ms(part)
        for (off, dur, txt) in chunk_subs:
            s = base_ms + off / 10000.0
            e = base_ms + (off + dur) / 10000.0
            subs.append((s, e, txt.strip()))
        base_ms += dur_ms
        parts.append(part)

    if len(parts) == 1:
        shutil.move(str(parts[0]), str(out_mp3))
    else:
        concat_mp3(parts, out_mp3)

    if make_subtitle and subs:
        if sub_format in ("srt", "both"):
            write_srt(subs, out_mp3.with_suffix(".srt"))
        if sub_format in ("lrc", "both"):
            write_lrc(subs, out_mp3.with_suffix(".lrc"))
        generate_player(subs, out_mp3, embed=embed)
    return subs


def concat_mp3(parts, out_path):
    if len(parts) == 1:
        shutil.move(str(parts[0]), str(out_path))
        return
    list_file = out_path.with_suffix(".list.txt")
    list_file.write_text("\n".join(f"file '{p}'" for p in parts), encoding="utf-8")
    subprocess.check_call([
        "ffmpeg", "-y", "-f", "concat", "-safe", "0",
        "-i", str(list_file), "-c", "copy", str(out_path)
    ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    list_file.unlink()
    for p in parts:
        p.unlink(missing_ok=True)


def ms_to_srt(ms):
    ms = int(ms)
    h = ms // 3_600_000
    ms %= 3_600_000
    m = ms // 60_000
    ms %= 60_000
    s = ms // 1000
    ms %= 1000
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def write_srt(subs, path):
    with open(path, "w", encoding="utf-8") as f:
        for i, (s, e, t) in enumerate(subs, 1):
            f.write(f"{i}\n{ms_to_srt(s)} --> {ms_to_srt(e)}\n{t}\n\n")
    print(f"📝 字幕(SRT)：{path}")


def write_lrc(subs, path):
    def lrc_ts(ms):
        s = ms / 1000.0
        m = int(s // 60)
        sec = s - m * 60
        return f"[{m:02d}:{sec:05.2f}]"
    with open(path, "w", encoding="utf-8") as f:
        for (s, e, t) in subs:
            f.write(f"{lrc_ts(s)}{t}\n")
    print(f"📝 字幕(LRC)：{path}")


PLAYER_TEMPLATE = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>__TITLE__ · 同步字幕</title>
<style>
  :root { color-scheme: light dark; }
  body { font-family: -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif;
         max-width: 760px; margin: 0 auto; padding: 24px; line-height: 1.8; }
  h1 { font-size: 20px; }
  audio { width: 100%; margin: 16px 0; }
  #subs { margin-top: 12px; }
  .line { padding: 6px 10px; border-radius: 8px; color: #888; transition: all .2s; cursor: pointer; }
  .line.active { background: #fff3cd; color: #111; font-weight: 600; }
  .meta { color: #999; font-size: 13px; }
</style>
</head>
<body>
  <h1>__TITLE__</h1>
  <p class="meta">__NOTE__</p>
  <audio id="audio" controls preload="auto" src="__AUDIO__"></audio>
  <div id="subs"></div>
<script>
  const subs = __DATA__;
  const audio = document.getElementById('audio');
  const box = document.getElementById('subs');
  const els = subs.map((s, i) => {
    const d = document.createElement('div');
    d.className = 'line';
    d.textContent = s.text;
    d.onclick = () => { audio.currentTime = s.start; audio.play(); };
    box.appendChild(d);
    return d;
  });
  let cur = -1;
  audio.addEventListener('timeupdate', () => {
    const t = audio.currentTime;
    let idx = -1;
    for (let i = 0; i < subs.length; i++) {
      if (t >= subs[i].start && t < subs[i].end) { idx = i; break; }
    }
    if (idx !== cur) {
      if (cur >= 0) els[cur].classList.remove('active');
      if (idx >= 0) {
        els[idx].classList.add('active');
        els[idx].scrollIntoView({ block: 'center', behavior: 'smooth' });
      }
      cur = idx;
    }
  });
</script>
</body>
</html>
"""


EMBED_LIMIT_MB = 30  # auto 模式下，mp3 不超过该大小才内嵌


def generate_player(subs, out_mp3, embed="auto"):
    """生成同步字幕播放器。embed: True 强制内嵌 / False 外链 / "auto" 按大小。"""
    out_mp3 = Path(out_mp3)
    path = out_mp3.with_suffix(".html")
    data = [{"start": s / 1000.0, "end": e / 1000.0, "text": t} for (s, e, t) in subs]

    do_embed = (embed is True) or (embed == "auto" and
                                   out_mp3.stat().st_size <= EMBED_LIMIT_MB * 1024 * 1024)
    if do_embed:
        b64 = base64.b64encode(out_mp3.read_bytes()).decode("ascii")
        audio_src = f"data:audio/mpeg;base64,{b64}"
        note = "点击任意一句可跳转；播放时当前句自动高亮并滚动。（音频已内嵌，本文件可单独分享）"
        tag = "（音频已内嵌，单文件可分享）"
    else:
        audio_src = out_mp3.name
        note = "点击任意一句可跳转；播放时当前句自动高亮并滚动。（需与同名 mp3 放在同一目录）"
        tag = ""

    html = (PLAYER_TEMPLATE
            .replace("__TITLE__", path.stem)
            .replace("__AUDIO__", audio_src)
            .replace("__NOTE__", note)
            .replace("__DATA__", json.dumps(data, ensure_ascii=False)))
    path.write_text(html, encoding="utf-8")
    print(f"🖥️ 同步字幕播放器(HTML)：{path}{tag}")


# --------------------------------------------------------------------------- #
# 命名
# --------------------------------------------------------------------------- #
def safe_filename(name, fallback="web-audio"):
    name = re.sub(r"[\\/:*?\"<>|]", "_", name or "").strip()
    return name[:60] or fallback


def build_output_paths(template, title, voice, lang, explicit_output):
    """返回 out_mp3 路径；命名规则可由模板/显式参数决定。"""
    if explicit_output:
        out_mp3 = Path(explicit_output)
    else:
        date = datetime.now().strftime("%Y%m%d_%H%M")
        safe_v = re.sub(r"[^A-Za-z0-9]+", "-", voice or "")
        try:
            name = template.format(title=safe_filename(title) or "朗读内容",
                                   voice=safe_v, date=date, lang=lang)
        except Exception:
            name = safe_filename(title) or "朗读内容"
        out_mp3 = Path(f"{name}.mp3")
    return out_mp3


# --------------------------------------------------------------------------- #
# 入口
# --------------------------------------------------------------------------- #
def main():
    ap = argparse.ArgumentParser(description="把网页/HTML/MD/TXT 正文读懂并朗读为 mp3（可同步字幕）")
    ap.add_argument("source", nargs="?", help="网页 URL 或本地文件路径（HTML/MD/TXT）")
    ap.add_argument("--url", help="网页地址")
    ap.add_argument("--file", help="本地文件路径（HTML/MD/TXT）")
    ap.add_argument("--text", help="直接传入要朗读的文本（理解重组后用）")
    ap.add_argument("--text-file", help="读取文本文件作为朗读素材")
    # 语音 / 音色（均可配置）
    ap.add_argument("--voice", help="语音名，如 zh-CN-YunyangNeural")
    ap.add_argument("--lang", help="语言前缀，决定默认语音（zh/en）")
    ap.add_argument("--rate", help="语速，如 +10%% / -5%% / slow / fast")
    ap.add_argument("--volume", help="音量，如 +0%% / -10%% / loud")
    # 输出 / 命名
    ap.add_argument("--max-chars", type=int, help="每块合成文本最大字符数")
    ap.add_argument("--output", help="输出 mp3 完整路径（含扩展名），优先级最高")
    ap.add_argument("--name-template", help="命名模板：{title}{voice}{date}{lang}")
    # 字幕
    ap.add_argument("--subtitle", dest="subtitle", action="store_true", default=None, help="生成同步字幕（默认）")
    ap.add_argument("--no-subtitle", dest="subtitle", action="store_false", default=None, help="不生成字幕")
    ap.add_argument("--sub-format", choices=["srt", "lrc", "both"], help="字幕格式")
    ap.add_argument("--embed-audio", dest="embed_audio", action="store_true", default=None,
                    help="把音频内嵌进 HTML 播放器（单文件可分享）")
    ap.add_argument("--no-embed", dest="embed_audio", action="store_false", default=None,
                    help="不内嵌音频（HTML 需与 mp3 同目录）")
    # 其它
    ap.add_argument("--config", help="JSON 配置文件路径")
    ap.add_argument("--no-install", action="store_true", help="依赖缺失时不自动安装")
    args = ap.parse_args()

    if not ensure_deps(allow_install=not args.no_install):
        sys.exit(1)

    cfg = load_config(args.config)

    lang = args.lang or cfg.get("lang", BUILTIN_DEFAULTS["lang"])
    voice = (args.voice or cfg.get("voice") or
             DEFAULT_VOICES.get(lang, DEFAULT_VOICES["zh"]))
    rate = args.rate or cfg.get("rate", BUILTIN_DEFAULTS["rate"])
    volume = args.volume or cfg.get("volume", BUILTIN_DEFAULTS["volume"])
    max_chars = args.max_chars or cfg.get("max_chars", BUILTIN_DEFAULTS["max_chars"])
    output_template = args.name_template or cfg.get("output_template", BUILTIN_DEFAULTS["output_template"])
    if args.subtitle is not None:
        subtitle = args.subtitle
    else:
        subtitle = cfg.get("subtitle", BUILTIN_DEFAULTS["subtitle"])
    sub_format = args.sub_format or cfg.get("sub_format", BUILTIN_DEFAULTS["sub_format"])
    if args.embed_audio is not None:
        embed_mode = args.embed_audio
    else:
        embed_mode = cfg.get("embed_audio", "auto")  # True / False / "auto"

    # 文本来源
    if args.text:
        title, text = "", args.text.strip()
    elif args.text_file:
        title, text = "", Path(args.text_file).read_text(encoding="utf-8", errors="ignore").strip()
    else:
        source = args.url or args.file or args.source
        if not source:
            ap.error("必须提供网页 URL / 本地文件（HTML/MD/TXT），或用 --text/--text-file 直接给文本。")
        is_url = str(source).startswith("http://") or str(source).startswith("https://")
        try:
            if is_url:
                if is_workbuddy_share(source):
                    title, text = fetch_workbuddy_text(source)
                else:
                    title, text = fetch_url_text(source)
            else:
                title, text = read_file_text(source)
        except Exception as e:
            print(f"❌ 读取内容失败：{e}", file=sys.stderr)
            sys.exit(1)

    if not text:
        print("❌ 没有可朗读的文本内容。", file=sys.stderr)
        sys.exit(1)

    print(f"📝 待朗读文本（约 {len(text)} 字）{('：' + title[:40]) if title else ''}")

    out_mp3 = build_output_paths(output_template, title, voice, lang, args.output)
    out_mp3.parent.mkdir(parents=True, exist_ok=True)

    import tempfile
    tmp_dir = Path(tempfile.mkdtemp(prefix="wara_"))
    try:
        asyncio.run(synthesize(text, voice, rate, volume, max_chars,
                               out_mp3, tmp_dir, subtitle, sub_format, embed_mode))
    except Exception as e:
        print(f"❌ 语音合成失败：{e}", file=sys.stderr)
        sys.exit(1)
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)

    size = out_mp3.stat().st_size / 1024
    print(f"✅ 已生成音频：{out_mp3.resolve()}（{size:.0f} KB）")


if __name__ == "__main__":
    main()
