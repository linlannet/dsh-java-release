---
name: md-wecan
description: "各类文本资源快速处理助手：把散乱的 MD / TXT / PDF / 网页文章整理为统一版式，一键生成多端适配的苹果风 MD（Apple 设计语言），导出网页阅读版 HTML、微信公众号稿（全内联样式，整段粘贴不掉格式）、打印版 HTML（A4 分页，打印即得 PDF）、分享海报图（定尺画布，可导出 PNG），方便分析、关联、分享和建立个人知识库。含格式检查器（lint）与来源预处理（ingest）。当用户提到 md 排版、文本资源整理、知识库入库、文章规范化、导出 HTML、公众号排版、生成 PDF、生成海报图、TXT/PDF 转 Markdown、知识笔记排版、一键导出时使用。"
version: 1.1.0
display_name: "MD工具助手"
display_name_en: "MD Toolkit"
description_zh: "各类文本资源快速处理助手，一键生成多端适配的苹果风MD，方便分析、关联、分享和建立个人知识库。"
description_en: "A fast assistant for any text source. One command turns Markdown, TXT or PDF into clean, Apple-styled Markdown that renders well on web, WeChat and print — built for analysis, cross-linking, sharing and personal knowledge bases."
category: writing
author: "个人开发者"
---

# MD工具助手（md-wecan）

各类文本资源快速处理助手。一套书写约定 + 一个渲染器 + 四个输出去向：写一次，同时得到网页阅读版、微信公众号稿、打印导出 PDF、分享海报图。

视觉遵循 Apple（iOS / macOS）设计语言：系统色板、SF 字体栈、连续圆角、卡片化层级、深色模式。产出的 MD 结构统一、可检索、可关联、可分享，既可直接阅读，也适合作为个人知识库的标准条目。

## 何时用我

- 用户给了一篇 MD / TXT / PDF，要求「排版好看」「规范化」「做成可分享的页面」
- 用户要把文章发到微信公众号，要求粘贴后不掉格式
- 用户要把文章导出 PDF（打印版 HTML，浏览器打印即得）
- 用户要一张分享海报 / 朋友圈图 / 封面图，要求标题、金句、章节一图说清
- 用户要做知识笔记整理或知识库入库，要求格式统一、结构清晰、便于后续分析关联

## 快速上手（三条命令）

所有脚本均可用任何 Python 3.8+ 运行，零第三方依赖（仅 PDF 抽取需要 `pypdf`，缺失时脚本会提示）。

```bash
# 1. 规范检查：先看问题清单
python3 scripts/lint_md.py 文章.md

# 2. 一键导出：网页版（默认，同名 .html）
python3 scripts/md2html.py 文章.md

# 3. 四份一起导：网页 + 公众号 + 打印 + 海报
python3 scripts/md2html.py 文章.md --mode all --theme azure

# 4. 只要海报图：默认 3:4 封面版，直接出 PNG
python3 scripts/md2html.py 文章.md --mode poster --poster-png
```

来源是 TXT / PDF 时，先用 ingest 生成规范化草稿，再整理内容：

```bash
python3 scripts/ingest.py 来源.pdf -o 文章.md   # PDF → 结构化 md 草稿
python3 scripts/ingest.py 来源.txt -o 文章.md
```

## 产物说明

| 模式 | 参数 | 产物 | 用法 |
|------|------|------|------|
| web | `--mode web`（默认） | `文章.html`，单文件含样式 | 直接预览、分享、归档 |
| wechat | `--mode wechat` | `文章.wechat.html`，纯正文+全内联样式 | 浏览器打开→全选→复制→粘贴进公众号编辑器 |
| print | `--mode print` | `文章.print.html`，A4 分页样式 | 浏览器打开→打印→存储为 PDF |
| poster | `--mode poster` | `文章.poster.html`；加 `--poster-png` 出 `文章.poster.png` | 分享、朋友圈、封面图 |
| all | `--mode all` | 以上四份 | 一稿多发 |

主题（Apple 系统配色）：`--theme azure`（iOS 浅色·默认）/ `ink`（iOS 深色）/ `warm`（iOS 浅暖）。深色策略：`--scheme auto|light|dark`（auto 跟随系统）。查看主题详情：`python3 scripts/md2html.py --themes`。frontmatter 里写 `theme: ink` 同样生效。

海报：`--poster-ratio 3:4|4:5|1:1|9:16`，`--poster-layout cover|list|quote`。

## 标准工作流（AI 执行时遵循）

1. **识别来源**：`.md` 直接进入第 3 步；`.txt` / `.pdf` 先跑 `ingest.py` 生成草稿。
2. **整理内容**：ingest 产出是**草稿**——必须复核：删广告噪音与页眉页脚、修正粘连的章节标题、提炼章节导语、补全 frontmatter（title / subtitle / author / date / tags / quote）。忠实原文，不臆造事实。
3. **规范检查**：跑 `lint_md.py`，处理 error 级问题（frontmatter 未闭合、标题跳级、编号重复、围栏未闭合）。可用 `--fix` 自动修复部分问题。
4. **一键导出**：按用户需求选模式；用户说「发公众号」就导 wechat，「导 PDF」就导 print，「要张海报/封面图」就导 poster，「看看效果」就导 web 并用预览工具打开。
5. **交付**：给出文件路径 + 简要说明产物用法（尤其 wechat 版的粘贴方法）。

## MD 书写约定（渲染器依赖）

完整规范见 `references/conventions.md`，要点：

````markdown
---
title: 文章标题            # 必填
subtitle: 副标题
kicker: 顶部栏目名
author: 作者
date: 2026-01-01
tags: [标签一, 标签二]
quote: 金句（渲染进横幅）
theme: azure               # azure | ink | warm
---

## 01 章节标题              # 数字自动变成大号水印编号 + 目录锚点
> 紧跟章节的普通引用 → 渲染为章节导语

> [!NOTE] 蓝色提示框       # 另有 TIP绿 / IMPORTANT金 / WARNING红
> 提示正文

> 💡 emoji 也能触发提示框   # ✅绿 ⚠️🚨红 💡🔑金 其余蓝

1. **步骤标题** 说明文字     # 有序列表且以加粗开头 → 圆形序号步骤卡

| 列 | 列 |                  # 表格自动美化
|---|---|

```grid
名称 | 标签 | 一句说明       # → 三列彩色卡片网格（3/2 列自适应）
```

<!-- pagebreak -->          # 打印模式下强制分页
````

## 质量红线

- 渲染前必跑 lint；error 不清零不交付。
- 公众号稿交付时必须说明「浏览器打开 wechat.html → 全选复制 → 粘贴」，并提醒图片需在公众号编辑器内重新上传。
- print 版导出 PDF 后建议检查：表格无断行、卡片无跨页断裂。
- 海报交付时必须说明：`--poster-png` 依赖本机 Chrome / Edge / Chromium 无头截图；没装浏览器就只给 HTML，让用户自行截图，不要谎称已生成图片。
- 不修改用户观点与事实内容；排版整理不等于内容改写。

## 发布说明

- 打包：`python3 build_skill_pack.py <技能目录> [输出目录]`，zip 第一层直接是 SKILL.md。
- 重新上传前必须递增 `version`（平台不允许覆盖已记录版本）。
- 上传入口：open.workbuddy.cn/skill/publish
