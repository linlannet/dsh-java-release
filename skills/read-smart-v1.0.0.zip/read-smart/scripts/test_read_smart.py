#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
read-smart 单元测试（不依赖网络 / ffmpeg / edge-tts）。
运行：python3 -m unittest scripts/test_read_smart.py -v
"""

import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import read_smart as R


class TestPure(unittest.TestCase):
    def test_safe_filename(self):
        self.assertEqual(R.safe_filename('a/b:c*?'), 'a_b_c__')
        self.assertEqual(R.safe_filename(''), 'web-audio')

    def test_split_text_no_break(self):
        t = "这是一句。这是二句。短。"
        chunks = R.split_text(t, 100)
        self.assertEqual(len(chunks), 1)  # 短文本不应被切断

    def test_split_text_long(self):
        t = "甲" * 500 + "。"
        chunks = R.split_text(t, 200)
        self.assertTrue(all(len(c) <= 200 for c in chunks))
        self.assertTrue("".join(chunks).startswith("甲" * 500))

    def test_ms_to_srt(self):
        self.assertEqual(R.ms_to_srt(0), "00:00:00,000")
        self.assertEqual(R.ms_to_srt(65432), "00:01:05,432")

    def test_build_output_paths_explicit(self):
        p = R.build_output_paths("{title}", "标题", "zh-CN-X", "zh", "/tmp/out.mp3")
        self.assertEqual(str(p), "/tmp/out.mp3")

    def test_build_output_paths_template(self):
        p = R.build_output_paths("{date}_{title}", "我的文章", "zh-CN-X", "zh", None)
        self.assertTrue(p.name.startswith("20"))   # 日期前缀
        self.assertIn("我的文章", p.name)
        self.assertTrue(p.name.endswith(".mp3"))

    def test_load_config(self):
        f = Path(tempfile.mktemp(suffix=".json"))
        f.write_text(json.dumps({"voice": "zh-CN-YunyangNeural"}), encoding="utf-8")
        cfg = R.load_config(str(f))
        self.assertEqual(cfg["voice"], "zh-CN-YunyangNeural")
        f.unlink()

    def test_load_config_missing(self):
        self.assertEqual(R.load_config("/nonexistent/xyz.json"), {})

    def test_decode_bytes(self):
        self.assertEqual(R._decode_bytes("你好".encode("utf-8")), "你好")
        self.assertEqual(R._decode_bytes("你好".encode("gbk")), "你好")

    def test_is_workbuddy_share(self):
        self.assertTrue(R.is_workbuddy_share("https://workbuddy.link/p/abc"))
        self.assertTrue(R.is_workbuddy_share("https://www.workbuddy.cn/space/d/abc"))
        self.assertFalse(R.is_workbuddy_share("https://example.com/article"))

    def test_extract_plain_text_md(self):
        raw = "# 我的标题\n\n这是**第一**段。\n\n- 列表项一\n- 列表项二\n\n[链接](https://x.com) 与 `代码`。"
        title, text = R._extract_plain_text(raw)
        self.assertEqual(title, "我的标题")
        self.assertNotIn("**", text)
        self.assertNotIn("https://x.com", text)
        self.assertIn("第一段", text)
        self.assertIn("列表项一", text)
        self.assertIn("链接", text)
        self.assertIn("代码", text)

    def test_extract_plain_text_txt(self):
        raw = "纯文本第一行\n第二行内容。"
        title, text = R._extract_plain_text(raw)
        self.assertEqual(title, "纯文本第一行")
        self.assertIn("第二行内容", text)

    def test_read_file_text_md(self):
        f = Path(tempfile.mktemp(suffix=".md"))
        f.write_text("# 标题A\n\n正文B。", encoding="utf-8")
        title, text = R.read_file_text(str(f))
        self.assertEqual(title, "标题A")
        self.assertIn("正文B", text)
        f.unlink()


class TestExtract(unittest.TestCase):
    def test_extract_main_text(self):
        from bs4 import BeautifulSoup
        html = ('<html><head><title>测试标题</title></head><body>'
                '<nav>导航</nav><script>var a=1;</script>'
                '<h1>测试标题</h1><p>第一段内容。</p><p>第二段。</p></body></html>')
        soup = BeautifulSoup(html, "html.parser")
        title, text = R.extract_main_text(soup, "x")
        self.assertEqual(title, "测试标题")
        self.assertNotIn("导航", text)
        self.assertNotIn("var a", text)
        self.assertEqual(text.count("测试标题"), 1)   # 标题块 + 去重后的 h1，仅出现一次
        self.assertIn("第一段内容。", text)
        self.assertTrue(text.startswith("测试标题。"))  # 标题补句号独立成句


class TestWorkbuddyExtract(unittest.TestCase):
    def test_fetch_workbuddy_text_via_static_url(self):
        import requests
        shell = ('<html><body>正在加载发布页面<script>var x=1;</script>'
                 '<!-- workbuddy-space-static.codebuddy.work/page/abc/123/文章.html -->'
                 '</body></html>')
        real = ('<html><head><title>真实文章</title></head>'
                '<body><p>正文第一段。</p><p>第二段。</p></body></html>')
        shell_resp = MagicMock(); shell_resp.text = shell; shell_resp.raise_for_status = lambda: None
        real_resp = MagicMock(); real_resp.content = real.encode("utf-8"); real_resp.raise_for_status = lambda: None
        with patch.object(requests, "get", side_effect=[shell_resp, real_resp]):
            title, text = R.fetch_workbuddy_text("https://workbuddy.link/p/abc")
        self.assertEqual(title, "真实文章")
        self.assertIn("正文第一段。", text)
        self.assertIn("第二段。", text)

    def test_fetch_workbuddy_text_via_bootstrap(self):
        import requests
        shell = ('<html><body>加载中<script>__PUBLISH_BOOTSTRAP__ = '
                 '{"assetBase":"https://workbuddy-space-static.codebuddy.work/page/abc/123",'
                 '"title":"我的文章.html"};</script></body></html>')
        real = '<html><head><title>Boot文章</title></head><body><p>内容。</p></body></html>'
        shell_resp = MagicMock(); shell_resp.text = shell; shell_resp.raise_for_status = lambda: None
        real_resp = MagicMock(); real_resp.content = real.encode("utf-8"); real_resp.raise_for_status = lambda: None
        with patch.object(requests, "get", side_effect=[shell_resp, real_resp]):
            title, text = R.fetch_workbuddy_text("https://workbuddy.link/p/xyz")
        self.assertEqual(title, "Boot文章")
        self.assertIn("内容。", text)

    def test_fetch_workbuddy_text_no_resource(self):
        import requests
        shell = '<html><body>加载中但无资源</body></html>'
        shell_resp = MagicMock(); shell_resp.text = shell; shell_resp.raise_for_status = lambda: None
        with patch.object(requests, "get", return_value=shell_resp):
            with self.assertRaises(ValueError):
                R.fetch_workbuddy_text("https://workbuddy.link/p/empty")


if __name__ == "__main__":
    unittest.main()
